<?php
/**
 * clubforrental functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package clubforrental
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function clubforrental_setup() {
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on clubforrental, use a find and replace
		* to change 'clubforrental' to the name of your theme in all the template files.
		*/
	load_theme_textdomain( 'clubforrental', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support( 'title-tag' );

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__( 'Primary', 'clubforrental' ),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'clubforrental_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action( 'after_setup_theme', 'clubforrental_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function clubforrental_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'clubforrental_content_width', 640 );
}
add_action( 'after_setup_theme', 'clubforrental_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function clubforrental_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', 'clubforrental' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'clubforrental' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
	
	// Footer #1.
	register_sidebar(
	
			array(
				'name'        => __( 'Footer 1', 'Club_for_rental' ),
				'id'          => 'footer-1',
				'before_widget' => '<div class="col-lg-4 col-md-4 col-sm-4"><div class="contact-links">',
				'after_widget'  => '</div></div>',
				'description' => __( 'Widgets in this area will be displayed in the first column in the footer.', 'Club_for_rental' ),
			)
		
	);

	// Footer #2.
	register_sidebar(
			array(
				'name'        => __( 'Footer 2', 'Club_for_rental' ),
				'id'          => 'footer-2',
				'before_widget' => '<div class="col-lg-4 col-md-4 col-sm-4"><div class="social-links">',
				'after_widget'  => '</div></div>',
				'description' => __( 'Widgets in this area will be displayed in the second column in the footer.', 'Club_for_rental' ),
			)
		
	);
	
	// Footer #3.
	register_sidebar(
			array(
				'name'        => __( 'Footer 3', 'Club_for_rental' ),
				'id'          => 'footer-3',
				'before_widget' => '<div class="col-lg-4 col-md-4 col-sm-4"><div class="footer-links">',
				'after_widget'  => '</div></div>',
				'description' => __( 'Widgets in this area will be displayed in the second column in the footer.', 'Club_for_rental' ),
			)
		
	);

	// Copyright.
	register_sidebar(
			array(
				'name'        => __( 'Copyright', 'Club_for_rental' ),
				'id'          => 'footer_copyright',
				'before_widget' => '<div class="copy-ryt text-center">',
				'after_widget'  => '</div>',
				'description' => __( 'Widgets in this area will be displayed in the second column in the footer.', 'Club_for_rental' ),
			)
		
	);
}
add_action( 'widgets_init', 'clubforrental_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function clubforrental_scripts() {
	wp_enqueue_style( 'clubforrental-style', get_stylesheet_uri(), array(), _S_VERSION );
	wp_style_add_data( 'clubforrental-style', 'rtl', 'replace' );

	wp_enqueue_script( 'clubforrental-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'clubforrental_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**  Club-For-Rental code Starts here **/
require get_template_directory() . '/inc/code/custom-function.php';

