<?php 
	//Template Name:Contact Us
	get_header();
?>
<!-------------------------------- Banner Section -------------------------------------------->
<?php if(has_post_thumbnail()) :
		$imagepath=wp_get_attachment_image_src(get_post_thumbnail_id()); ?>
			<section class="main-banner-sc" style="background-image:url(<?php echo $imagepath[0]; ?>);">
				<div class="container">
					<div class="main-banner-sc-content">
						<h4><?php the_title(); ?></h4>
					</div>
				</div>
			</section>
<?php endif; ?>

	<section class="contact-sec">
        <div class="container">
		
		<?php if( get_field('main_heading')) :?>
            <div class="contact-tittle">
                <p><?php the_field('main_heading'); ?></p>
            </div>
		<?php endif; ?>
            <div class="contact-form">
                <div class="row">
				
				<?php if( have_rows('get_in_touch')) :
						while( have_rows('get_in_touch')) : the_row();
							if( get_sub_field('title') || have_rows('address_list') || have_rows('social_links') || get_sub_field('image')) :?>
								<div class="col-md-6">
									<div class="get-in">
									
									<?php if( get_sub_field('title')) :?>
										<h4><?php the_sub_field('title'); ?></h4>
									<?php endif; ?>
									
									<?php if( have_rows('address_list')) :?>
												<div class="get-list">
													<ul>
													<?php while( have_rows('address_list')) : the_row(); 
														if( get_sub_field('icon') || get_sub_field('text')) :?>
															<li><a href=""><i class="<?php the_sub_field('icon') ?>"></i><?php the_sub_field('text'); ?></a></li>
													<?php endif; endwhile; ?>
												
													</ul>
												</div>
									<?php endif; ?>
									
									<?php if( have_rows('social_links')) : ?>
												 <div class="get-social">
													<ul class="d-flex">
													<?php while( have_rows('social_links')) : the_row();
															if( get_sub_field('icon') || get_sub_field('text') || get_sub_field('url')) :?>
																<li><a href="<?php the_sub_field('url'); ?>"><i class="<?php the_sub_field('icon') ?>"></i><?php the_sub_field('text'); ?></a></li> 
													<?php endif; endwhile; ?>
														
													</ul>
												</div>
												
									<?php endif; ?>
									   
									<?php if( get_sub_field('image')) :?>
										<div class="get-img">
											<img src="<?php the_sub_field('image'); ?>" alt="" class="img-fluid">
										</div>
									<?php endif; ?>
									</div>
								</div>
				<?php endif; endwhile; endif; ?>
				
                    <div class="col-md-6">
                        <div class="message-sec">
						
						<?php if( have_rows('send_message')) :
								while( have_rows('send_message')) : the_row();
									if( get_sub_field('title')) :?>
										<div class="message-text">
											<h4><?php the_sub_field('title'); ?></h4>
										</div>
						<?php endif; endwhile; endif; ?>
                            <div class="message-form">
                                <?php echo do_shortcode('[contact-form-7 id="152" title="Contant Page Form"]'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php get_footer(); ?>