<?php 
	//Template Name: About Us
	get_header();
?>

<?php if(has_post_thumbnail()) :
		$imagepath=wp_get_attachment_image_src(get_post_thumbnail_id()); ?>
		
			<section class="main-banner-sc"style="background-image:url(<?php echo $imagepath[0]; ?>);">
				<div class="container">
					<div class="main-banner-sc-content">
						<h4><?php the_title(); ?></h4>
					</div>
				</div>
			</section>
<?php endif; ?>

<!-------------------------------- Right Side Image About Section -------------------------------------------->

<?php if( get_field('right_image') || have_rows('left_content')) :?>
	<section class="golf-lifestyle-sec">
		<div class="container">
			<div class="about-company-sec-content">
				<div class="row">
				
				<?php if(  have_rows('left_content')) :
						while( have_rows('left_content')): the_row();?>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="about-comany-left">
						
							<?php if( get_sub_field('main_heading')) :?>
								<h2 class="headh2 grn"><?php the_sub_field('main_heading'); ?></h2>
							<?php endif; ?>
							
							<?php if( get_sub_field('description')) :?>
								<?php the_sub_field('description'); ?>
							<?php endif; ?>
							
							<?php if( have_rows('add_button')) :
											while( have_rows('add_button')) : the_row();
												if( get_sub_field('button_text') || get_sub_field('button_url')) :?>
													<div class="main-btn">
														<a href="<?php the_sub_field('button_url'); ?>"><?php the_sub_field('button_text'); ?></a>
													</div>
							<?php endif; endwhile; endif; ?>	
						</div>
					</div>
				<?php endwhile; endif; ?>
				
				<?php if( get_field('right_image')) :?>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="about-comany-right">
							<img src="<?php the_field('right_image') ?>" class="img-fluid">
						</div>
					</div>
				<?php endif; ?>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php if( get_field('video_poster') || get_field('video_url')) :?>
	<section class="video_sec">
			<div class="play-video">
				<video id="video" class="video-js " controls preload="auto" poster="<?php the_field('video_poster'); ?>" data-setup='{ "techOrder": ["youtube"], "sources": [{ "type": "video/youtube", "src": "<?php the_field('video_url'); ?>"}], "youtube": { "customVars": { "wmode": "transparent" } } }'>
					</video>
			</div>
	 </section>
<?php endif; ?>


<!-------------------------------- Left Side Image About Section -------------------------------------------->
<?php if( get_field('left_image') || have_rows('right_content')) :?>
	<section class="golf-lifestyle-sec">
		<div class="container">
			<div class="golf-lifestyle-sec-content">
				<div class="row">
				
				<?php if( get_field('left_image')) :?>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="golf-lifestyle-left">
							<img src="<?php the_field('left_image'); ?>" class="img-fluid">                        
						</div>
					</div>
				<?php endif; ?>
				
				<?php if(  have_rows('right_content')) :
						while( have_rows('right_content')): the_row();?>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="golf-lifestyle-right">
									<?php if( get_sub_field('main_heading')) :?>
										<h2 class="headh2 grn"><?php the_sub_field('main_heading'); ?></h2>
									<?php endif; ?>
									
									<?php if( get_sub_field('description')) :?>
										<?php the_sub_field('description'); ?>
									<?php endif; ?>
									
									<?php if( have_rows('add_button')) :
											while( have_rows('add_button')) : the_row();
												if( get_sub_field('button_text') || get_sub_field('button_url')) :?>
													<div class="main-btn">
														<a href="<?php the_sub_field('button_url'); ?>"><?php the_sub_field('button_text'); ?></a>
													</div>
									<?php endif; endwhile; endif; ?>
							
								</div>
							</div>
				<?php endwhile; endif; ?>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>
<?php get_footer(); ?>