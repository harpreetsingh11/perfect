<?php
	//Template Name:FAQS
	get_header();
?>
<!------------------------------- Banner section ------------------------------------>
<?php if(has_post_thumbnail()) :
		$imagepath=wp_get_attachment_image_src(get_post_thumbnail_id()); ?>
			<section class="main-banner-sc" style="background-image:url(<?php echo $imagepath[0]; ?>);">
				<div class="container">
					<div class="main-banner-sc-content">
						<h4><?php the_title(); ?></h4>
					</div>
				</div>
			</section>
<?php endif; ?>


<!------------------------------- FAQS section ------------------------------------>
<section class="faq-sec">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="faqs-drop-dowmn">
                        <div class="accordion" id="accordionExample">
						
						<?php if( have_rows('add_card')) :
								$i=1;
								while( have_rows('add_card')) : the_row();?>
									<div class="card">
									
										<?php if( get_sub_field('title')) :?>
											<div class="card-header" id="heading<?php echo $i; ?>" data-toggle="collapse" data-target="#collapse<?php echo $i; ?>"
												aria-expanded="true">
												<p class="mb-0"><strong><?php the_sub_field('title'); ?><i class="fa fa-plus" style="float:right;"></i></strong></p>
											</div>
										<?php endif; ?>
										
										<?php if( get_sub_field('inner_description')) :?>
											<div id="collapse<?php echo $i; ?>" class="collapse" aria-labelledby="heading<?php echo $i; ?>"
												data-parent="#accordionExample" style="">
												<div class="card-body">
													<?php the_sub_field('inner_description');  ?>
												</div>
											</div>
										<?php endif; ?>
										
									</div>
						<?php $i++; endwhile;  endif; ?>
                           
                        </div>
                    </div>
                </div>
                <?php if( get_field('add_image')) :?>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="faqs-image">
							<img src="<?php the_field('add_image'); ?>" class="img-fluid">
						</div>
					</div>
				<?php endif; ?>
            </div>
        </div>
    </section>

<?php get_footer(); ?>