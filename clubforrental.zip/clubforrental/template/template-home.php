<?php
	//Template Name:Home Page
	get_header();
?>

<!-------------------------------- Banner Section -------------------------------------------->
<?php if( get_field('add_banner_image') || get_field('main_banner_heading') || get_field('sub_banner_heading')):  ?>
	<section class="banner-sec"  style="background-image:url(<?php the_field('add_banner_image'); ?>);">
		<div class="container">
				<div class="banner-content">
				
				<?php if( get_field('main_banner_heading') || get_field('sub_banner_heading')): ?>
					<div class="banner-head text-center">
						<h1><?php the_field('main_banner_heading'); ?></h1>
						<p><?php the_field('sub_banner_heading'); ?></p>
					</div>
				<?php endif; ?>
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>


<!-------------------------------- Search Club Section -------------------------------------------->
<section class="search-club-sec"> 
    <div class="container-fluid">
        <div class="search-club-form">
            <form action="<?php echo home_url().'/club'; ?>" method="get">
                <div class="form-row">
				<div class="col-lg-1"></div>
                    <div class="col-lg-2 col-md-6 col-sm-6">
                       <div class="form-group">
                            <label for="exampleFormControlSelect1">Pickup Location</label>
                            <select class="form-control " id="exampleFormControlSelect1" name="location">
								<?php 								
									$terms = get_terms( 'location', array(
										'hide_empty' => false,
									) );
									foreach($terms as $term){
										?>
											<option value="<?php echo $term->slug; ?>"><?php echo $term->name; ?></option>
										<?php
									}
								?>
							
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="form-group">
                             <label>Pickup / Delivery Date and Time</label>
                             <span class="vriplacesp">
                            <!-- <input class="example" type="text" name="jQueryScript" value=""> -->
                            <input type="date" id="checkin-date" name="pickup_date"  class="form-control">
                            <select name="picktime" id="form_time" class="form-control" aria-label="Default select example"><?php echo get_times(); ?></select>            
                            </span>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="form-group">
                             <label>Drop Off / Collection Date and Time</label>
                             <span class="vriplacesp">
                            <!-- <input class="form-control" type="text" name="jQueryScript" value=""> -->
                            <input type="date" id="checkout-date" name="dropoff_date"  class="form-control example">
                            <select name="droptime" class="form-control" aria-label="Default select example"><?php echo get_times(); ?></select>
                            </span>
                        </div>
                    </div>
                    <div class=" col-lg-2 col-md-3 col-sm-3">
                        <div class="form-group">
                        <button type="submit" class="btn">Submit</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>


<!-------------------------------- Stick Slider Section -------------------------------------------->
<section class="stick-slider-sec">
    <div class="container">
        <div class="golf-stick-slider">
		
		<?php $club = array('post_type' => 'club', 'post_status' => 'publish', 'posts_per_page' => -1);
				$myclub = new WP_Query($club);
					if ($myclub->have_posts()) : 
						while ($myclub->have_posts()) : $myclub->the_post(); 
						 $get_product_id=get_field('select_parent_product');
							$product = wc_get_product( $get_product_id );  
								$imagepath = wp_get_attachment_image_src( get_post_thumbnail_id( $get_product_id ), 'single-post-thumbnail' );?>
							<div class="product-item">
								<div class="progam_box">
								
								<?php if( $imagepath) :?>
									<div class="pro_img">
										<img src="<?php echo $imagepath[0]; ?>" class="img-fluid">
									</div>
								<?php endif; ?>
									<div class="prog-price">
										<?php  echo $product->get_price_html(); ?> 
									</div>
									<div class="program_txt">
										<h5><?php  echo $product->get_name(); ?></h5>
										<?php $terms = get_the_terms( $product->get_id(), 'product_cat' );
														foreach ($terms as $term) { ?>
															<p><?php echo $term->name; ?></p>
														<?php } ?>
									</div>
									<div class="prgm-btn">
										<a href="<?php the_permalink(); ?>">Check Availability</a>
									</div>
								</div>
							</div>
				<?php endwhile; wp_reset_postdata(); endif; ?>
            
        </div>
    </div>
</section>


<!-------------------------------- Stick type Section -------------------------------------------->
<?php if( have_rows('add_stick_type')) :?>
	<section class="stick-type">
		<div class="row">
		
		<?php while( have_rows('add_stick_type')) : the_row(); ?>
			<div class="col-md-3 col-sm-6 col-12"><a href="<?php echo home_url("/club/"); ?>">
				<div class="stick-type-img">
				<?php if( get_sub_field('image')) :?>
					<img src="<?php the_sub_field('image'); ?>">
				<?php endif; ?>
				
				<?php if( get_sub_field('type')) : ?>
					<p><?php the_sub_field('type'); ?></p>
				<?php endif; ?>
				</div></a>
			</div>
		<?php endwhile; ?>

		</div>
	</section>
<?php endif; ?>


<!-------------------------------- Club-rental Section -------------------------------------------->

<?php if( get_field('add_image') || get_field('main_club_heading') || get_field('club_description')) :?>
	<section class="club-rentel-sec">
		<div class="container">
			<div class="row">
			
				<?php if( get_field('main_club_heading') || get_field('club_description')) :?>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="club-rentel-left">
							<h2 class="headh2"><?php the_field('main_club_heading'); ?></h2>
							<?php the_field('club_description'); ?>
						</div>
					</div>
				<?php endif; ?>
				
				<?php if( get_field('add_image')) :?>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="club-rentel-right">
							<img src="<?php the_field('add_image') ?>" class="img-fluid">
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php get_footer(); ?>