<?php 
	//Template Name:Testimonials
	get_header();
?>

<!------------------------------- Banner section ------------------------------------>
<?php if(has_post_thumbnail()) :
		$imagepath=wp_get_attachment_image_src(get_post_thumbnail_id()); ?>
			<section class="main-banner-sc" style="background-image:url(<?php echo $imagepath[0]; ?>);">
				<div class="container">
					<div class="main-banner-sc-content">
						<h4><?php the_title(); ?></h4>
					</div>
				</div>
			</section>
<?php endif; ?>

<!------------------------------- Testimonials section ------------------------------------>

<?php if( have_rows('add_testimonials')) :?>
	<section class="textimonial-sec">
		<div class="container">
			<div class="textimonial-sec-content">
				<div class="row">
				
				<?php while( have_rows('add_testimonials')): the_row(); 
						if( get_sub_field('message') || get_sub_field('name')) :?>
							<div class="col-lg-6 col-md-6 col-sm-6">
								<div class="testimonial-box">
								
								<?php if( get_sub_field('message')) :?>
									<p><?php the_sub_field('message'); ?></p>
								<?php endif; ?>
								
								<?php if( get_sub_field('name')) :?>
									<h6><?php the_sub_field('name'); ?></h6>
								<?php endif; ?>
								</div>
							</div>
				<?php endif; endwhile; ?>
					
				</div>
			</div>
		</div>
	</section>
<?php endif; ?>
<?php get_footer(); ?>