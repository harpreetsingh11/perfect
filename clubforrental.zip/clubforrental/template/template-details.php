<?php
	//Template Name:Detail Page
	get_header();
?>

<!-------------------------------- Banner Section -------------------------------------------->
<?php if(has_post_thumbnail()) :
		$imagepath=wp_get_attachment_image_src(get_post_thumbnail_id()); ?>
			<section class="main-banner-sc" style="background-image:url(<?php echo $imagepath[0]; ?>);">
				<div class="container">
					<div class="main-banner-sc-content">
						<h4><?php the_title(); ?></h4>
					</div>
				</div>
			</section>
<?php endif; ?>

<section class="Taylormade-about-sec">
        <div class="container">
            <div class="Taylormade-about-sec-comntent">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="Taylormade-about-left">
                            <img src="images/contain img1.png" class="img-fluid">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="Taylormade-about-right">
                            <p>Contains:</p>
                            <ul>
                                <li>M6 10.5º Regular Graphite Driver</li>
                                <li>M6 Regular Graphite 3 Wood,</li>
                                <li>M6 22° Graphite Hybrid / Rescue,</li>
                                <li>M6 Regular Steel 5 – SW Irons,</li>
                                <li>Odyssey White Hot Pro Blade Putter</li>
                                <li>Light Weight Stand / Carry Bag</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php get_footer(); ?>