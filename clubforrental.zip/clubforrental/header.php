<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package clubforrental
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
    <div class="container">
        <nav id="navbar_top" class="navbar navbar-expand-lg navbar-light">
		
		<?php if( have_rows('add_logo' , 'option') ): 
				while( have_rows('add_logo', 'option') ): the_row(); ?>
					<a class="nav-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php the_sub_field('logo') ?>"></a>
		<?php endwhile; endif; ?>
		
           <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
             <span class="navbar-toggler-icon"></span>
           </button>
            <?php 
					$menu=array(
							'menu'  => 'Header Menu',
							'container'       => 'div',
							'container_class' => 'collapse navbar-collapse',
							'container_id'    => 'navbarNavDropdown',
							'menu_class'      => 'navbar-nav ml-auto',
							);
					wp_nav_menu($menu);
				?>
        </nav>
    </div>
</header>

