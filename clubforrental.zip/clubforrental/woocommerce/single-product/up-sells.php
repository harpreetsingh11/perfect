<?php
/**
 * Single Product Up-Sells
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/up-sells.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
global $product;

if ( $upsells ) : ?>

	<section class="option-sec">
        <div class="container">
			<?php
			$heading = apply_filters( 'woocommerce_product_upsells_products_heading', __( 'Options Available', 'woocommerce' ) );

			if ( $heading ) :
				?>
				<div class="option-head">
					<h4><?php echo esc_html( $heading ); ?></h4>
					<div class="option-btn">
						<a href="">Club Rental Price: <span class="green"><?php echo $product->get_price_html(); ?></span></a>
					</div>
				</div>
			<?php endif; ?>
			
			
			<?php woocommerce_product_loop_start(); ?>
			<!---------------------------------- UP Sells Product ----------------------------------------->
			 <?php 			global $product;


							$product_id = $product->is_type('variation') ? $product->get_parent_id() : $product->get_id();
							$product = wc_get_product( $product_id );
							$upsell_ids = $product->get_upsell_ids();
								$args = array( 'post_type' => 'product' , 
												'post_status' => 'publish',
												'posts_per_page' => -1,
												'post__in'=> $upsell_ids,
												'order' => 'DSC',
							
											);

								$pro_cat = new WP_Query( $args );
								if( $pro_cat->have_posts()) :
								while ( $pro_cat->have_posts() ) : $pro_cat->the_post(); 
								?>

					<?php
					$post_object = get_post( $pro_cat->get_id() );

					setup_postdata( $GLOBALS['post'] =& $post_object ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, Squiz.PHP.DisallowMultipleAssignments.Found

					wc_get_template_part( 'content', 'single-linked-product' );
					?>

				<?php endwhile; wp_reset_query(); endif; ?> 
				
				<!---------------------------------- Cross Sells Product ----------------------------------------->
				<?php 			global $product;
							$product_id = $product->is_type('variation') ? $product->get_parent_id() : $product->get_id();
							$product = wc_get_product( $product_id );
							$cross_sell_ids = $product->get_cross_sell_ids();
								$args = array( 'post_type' => 'product' , 
												'post_status' => 'publish',
												'posts_per_page' => -1,
												'post__in'=> $cross_sell_ids,
												'order' => 'DSC',
							
											);

								$pro_cat = new WP_Query( $args );
								if( $pro_cat->have_posts() && !empty($cross_sell_ids)) :?>
									
								<section class="extra-club-sec">
									<div class="container">
										<h3>Extra Club Options Available</h3>
										<div class="row">
											<?php	while ( $pro_cat->have_posts() ) : $pro_cat->the_post(); ?>
												<?php
												$post_object = get_post( $pro_cat->get_id() );

												setup_postdata( $GLOBALS['post'] =& $post_object ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, Squiz.PHP.DisallowMultipleAssignments.Found

												wc_get_template_part( 'content', 'single-linked-product-cross-sell' );
												?>
											<?php endwhile; wp_reset_postdata();  ?> 
										</div> 
									</div>
								</section>
				<?php endif; ?>
				
			<?php woocommerce_product_loop_end(); ?>
			
			<div class="wedge-btns mb-5">
                <div class="bk-btn">
                    <a href="">back</a>
                </div>
                <div class="extra-btn">
                    <a href="">book now</a>
                </div>
            </div>
		</div>
	</section>
		
	<?php
endif;

wp_reset_postdata();
