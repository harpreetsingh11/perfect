<?php
/**
 * Checkout coupon form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-coupon.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.4.4
 */

defined( 'ABSPATH' ) || exit;

if ( ! wc_coupons_enabled() ) { // @codingStandardsIgnoreLine.
	return;
}

?>

<div class="addres-cupon slide-3">
 <div class="row my-5">
	<?php if(!is_user_logged_in()): ?>
		<div class="col-lg-6 col-md-6 col-md-12">
			<div class="cuppon-box login_sec">
				<h2>Returning Customer? <a href="#" class="returning_customer_button">Click here to login</a></h2>
				<div class="checkou_login_form">
					<h5>Please enter your detail below.</h5>
					<hr>
					<p class="login-username">
						<label for="user_login">Username or email*</label>
						<input type="text" name="log" id="user_login" autocomplete="username" class="input" value="" size="20" tabindex="0">
					</p>
					<p class="login-password">
						<label for="user_pass">Password*</label>
						<input type="password" name="pwd" id="user_pass" autocomplete="current-password" class="input" value="" size="20" tabindex="0">
					</p>
					<p class="login-remember"><label><input name="rememberme" type="checkbox" id="rememberme" value="forever" tabindex="0"> Remember Me</label></p>
					<p class="login-status"></p>
					<p class="login-submit">
						<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary" value="Log In" tabindex="0">
						<input type="hidden" name="redirect_to" value="http://sagmeticinfotech.com/wp/2022/clubhire/checkout/" tabindex="0">
					</p>
					<p class="lost-password">
						<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>" alt="<?php esc_attr_e( 'Lost Password', 'textdomain' ); ?>">
							<?php esc_html_e( 'Lost Password?', 'textdomain' ); ?>
						</a>
					</p>
				</div>
			</div>
		</div>	
	<?php endif; ?>
	<div class="<?php echo is_user_logged_in()?'col-lg-12 col-md-12':'col-lg-6 col-md-6'; ?> col-sm-12">
		<div class="cuppon-box">
			<h2>Have a coupon? <a href="#" class="cuppon_from_show_button">Click here to enter your code</a></h2>
			<div class="checkout_coupon woocommerce-form-coupon custom_checkout_coupon_form">
				<label>If you have a coupon code, please apply it below.</label>
				<div class="input-group">
					<input type="text" name="checkout_coupon_code" class="input-text form-control" placeholder="<?php esc_attr_e( 'Coupon code', 'woocommerce' ); ?>" id="checkout_coupon_code" value="" />
					 <div class="input-group-append">
						<button type="submit" class="button btn checkout_apply_coupon" name="checkout_apply_coupon" value="<?php esc_attr_e( 'Apply coupon ', 'woocommerce' ); ?>"><?php esc_html_e( 'Apply', 'woocommerce' ); ?></button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="container mt-5">
						<div class="row">
							<div class="col-6">
								<div class="prev-btn">
									<p class="prevStep" data-prev="1">Previous</p>
								</div>
							</div>
							<div class="col-6 d-flex justify-content-end">
								<div class="next-btn">
									<button type="button" id="thirdstep">NEXT</button>
								</div>
							</div>
						</div>
					</div>

</div>

	
