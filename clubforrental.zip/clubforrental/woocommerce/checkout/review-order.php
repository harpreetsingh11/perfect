<?php
/**
 * Review order table
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/review-order.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 5.2.0
 */

defined( 'ABSPATH' ) || exit;
$currency_symbol=get_woocommerce_currency_symbol();
$tax_rate = round( reset( WC_Tax::get_rates() )['rate'] );
?>
<div class="table-responsive slide-2">
    <table class="table">
		<thead>
			<tr>
                    <th scope="col"></th>
                    <th scope="col">Days</th>
                    <th scope="col">Net Price</th>
                    <th scope="col">Tax</th>
                    <th scope="col">Total Price</th>
             </tr>
		</thead>
		<tbody>
			<?php
			//do_action( 'woocommerce_review_order_before_cart_contents' );

			foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
				$_product = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );

				if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_checkout_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
					$item_price= $_product->get_price();
					$net_price = $item_price  - ($item_price  * ($tax_rate/100));
					$tax_price=$item_price - $net_price ;
					?>
					<tr>
					
						<th scope="row"><?php echo $_product->get_name(); ?></th>
						<td>
							<?PHP							
							echo get_cart_booking_days();
							?>
						</td>
						<td><?php echo $currency_symbol.' '.$net_price; ?></td>
						<td><?php echo $currency_symbol.' '.$tax_price; ?></td>
						<td><?php echo $currency_symbol.' '.$item_price; ?></td>
					</tr>
					<?php
				}
			}

			
			$total_items_price= WC()->cart->total; 
			$total_net_price = $total_items_price  - ($total_items_price  * ($tax_rate/100));
			$total_tax_price=$total_items_price - $total_net_price ;
			?>
					<tr class="Total-bill">
                        <th scope="row">Total</th>
                        <td></td>
                        <td><?php echo  $currency_symbol.' '.$total_net_price?></td>
                        <td><?php echo  $currency_symbol.' '.$total_tax_price?></td>
                        <td> <b><?php echo $currency_symbol.' '. $total_items_price?></b> </td> 
					</tr>
		</tbody>
	</table>
	<div class="order-changes">
                <div class="change-remove">
                <a href="<?php echo wc_get_checkout_url(); ?>/?change-date=1" class="change-date">Change Dates</a>
                <a href="<?php echo wc_get_checkout_url(); ?>/?clear-cart=1"  class="delete-data" id="empty_cart"><i class="fa-regular fa-trash-can"></i> Remove all Sets</a>
				
                </div>
     </div>
		<div class="container mt-5">
						<div class="row">
							<div class="col-6">
								<div class="prev-btn">
									<p class="prevStep" data-prev="0">Previous</p>
								</div>
							</div>
							<div class="col-6 d-flex justify-content-end">
								<div class="next-btn">
									<button type="button" class="btn-main" id="secondStep">NEXT</button>
								</div>
							</div>
						</div>
					</div>
	  
</div>



