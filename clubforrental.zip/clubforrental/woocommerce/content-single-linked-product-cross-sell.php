<!----------------------------------------- Extra Club Layout ------------------------------------------->
<?php global $product; ?>
<?php if( !empty( $cross_sell_ids) || get_field('select_linked_product_layout') == 'extra_club_layout'): $imagesrc = wp_get_attachment_image_src( get_post_thumbnail_id( $product->id ));?>


                <div class="col-md-6">
                    <div class="extra-club-content">
                        <div class="wedge">
                            <p><?php echo $product->name; ?>
                                <b><?php echo $product->get_price_html(); ?></b>
                            </p>
                            <label class="cont">
                                <input type="checkbox" checked="checked">
                                <span class="checkmark"></span>
                            </label>
                        </div>
						<?php if( $imagesrc): ?>
                        <div class="wedge-img">
                            <img src="<?php echo $imagesrc[0]; ?>" alt="" class="img-fluid">
                        </div>
						<?php endif; ?>
                    </div>
                </div>
                
           
<?php endif; ?>