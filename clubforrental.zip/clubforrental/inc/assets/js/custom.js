jQuery('.golf-stick-slider').slick({
    dots: false,
    infinite: true,
    arrows: true,
    speed: 300,
    slidesToShow: 3,
    slidesToScroll: 1,
   nextArrow: '<div class="slick-custom-arrow slick-custom-arrow-right"><i class="fa-solid fa-arrow-right"></i></div>',
    prevArrow: '<div class="slick-custom-arrow slick-custom-arrow-left"><i class="fa-solid fa-arrow-left"></i></div>',
    responsive: [{
            breakpoint: 1100,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                infinite: true,
            }
        }, {
            breakpoint: 1024,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                infinite: true,
            }
        },
        {
            breakpoint: 768,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                dots: false,
                arrows: false
            }
        },
        {
            breakpoint: 576,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: false,
                arrows: false
            }
        }
    ]
});
 $(document).ready(function(){
        // Add minus icon for collapse element which is open by default
        $(".collapse.show").each(function(){
          $(this).prev(".card-header").find(".fa").addClass("fa-minus").removeClass("fa-plus");
        });
        
        // Toggle plus minus icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function(){
          $(this).prev(".card-header").find(".fa").removeClass("fa-plus").addClass("fa-minus");
        }).on('hide.bs.collapse', function(){
          $(this).prev(".card-header").find(".fa").removeClass("fa-minus").addClass("fa-plus");
        });

         // Force all links to open in parent window
        $("a").click(function(){
            top.window.location.href=$(this).attr("href");
            return true;
        });
        jQuery('ul#menu-footer-menu > li > a').removeClass( 'nav-link' );

        jQuery('#option-available').hide();
        $("#submit-btn").click(function(event){
          event.preventDefault();
          jQuery('#option-available').show();
        });
    });

/* $(function(){
  $('.example').dateAndTime();
});
 */
// Time Now
/* $(function(){     
  var d = new Date(),        
      h = d.getHours(),
      m = d.getMinutes();
  if(h < 10) h = '0' + h; 
  if(m < 10) m = '0' + m; 
  $('input[type="time"][value="now"]').each(function(){ 
    $(this).attr({'value': h + ':' + m});
  });
}); */


let getcheckintime=$('#checkin-time').val();
$('#checkout-time').val(getcheckintime);

$('#checkin-time').change(function(){
	let getcheckintime=$('#checkin-time').val();
	$('#checkout-time').val(getcheckintime);
});


jQuery(document).ready(function($) {
	jQuery('#ajax_add_cart').on('click', function(event) {
		event.preventDefault();
		jQuery('.loading').show();
			let formdata= jQuery('#add_to_cart_form').serialize();
			 jQuery.ajax({
							url: wpObj.ajaxurl,
							type: 'post',
							data:  formdata,
							success: function (response) {	
									if(response.success == true) {
										jQuery('.loading').hide();
										window.location.href=response.url; 
									}else{
										alert('Failed! Please try again');
									}
								}
						});		
		});
		
		jQuery('#submit-btn-search').on('click',function(event){
			event.preventDefault();
			jQuery('.search_club_form_error').hide();
			let searchdata=jQuery('#search_form').serialize();
			jQuery.ajax({
				url: wpObj.ajaxurl,
				type: 'get',
				data: searchdata,
				success: function (response){
					if(response.success==true){
						jQuery('#option-available').show();	
						$('.club_total_price span.green').html('€ '+response.price);		
						$('#add_to_cart_form input[name="pickup_loc"]').val(response.pickup_loc);
						$('#add_to_cart_form input[name="pickup_date"]').val(response.pickup_date);
						$('#add_to_cart_form input[name="pickup_time"]').val(response.pickup_time);
						$('#add_to_cart_form input[name="dropoff_date"]').val(response.dropoff_date);
						$('#add_to_cart_form input[name="dropoff_time"]').val(response.dropoff_time);
					}else{
						jQuery('#option-available').hide();
						var post_title = jQuery('.search_club_form_error').attr('data-title');
						jQuery('.search_club_form_error').html(post_title+' is not available for the selected days. Please try with different dates');
						jQuery('.search_club_form_error').show();
					}
				}
			});
		});

	jQuery('.woocommerce-billing-fields  div:last').removeClass('col-lg-4 col-md-4 col-sm-12 mb-5');
	jQuery('.woocommerce-billing-fields  div:last').addClass('col-12 mb-3');
	jQuery('label.checkbox input').removeClass('form-control');
	jQuery('#billing_state_field').addClass('col-lg-4 col-md-4 col-sm-12 mb-5 ');

	jQuery('.woocommerce-additional-fields  div').removeClass('col-lg-4 col-md-4 col-sm-12 mb-5');
	jQuery('.woocommerce-additional-fields  div').addClass('form-group');
	jQuery('.woocommerce-additional-fields  div:last').addClass('hlf');
	jQuery(' .woocommerce-additional-fields  textarea').attr('rows', 3);
	jQuery(' .woocommerce-additional-fields  textarea:last').attr('rows', 1);

	$("#place_order " ).hide();



	$('.step_form').slick({
		slidesToShow: 1,
		adaptiveHeight: true,
		draggable: false,
		 dots: false,
		prevArrow: false,
		nextArrow: false,
		infinite: false,

	});		
	$('#firstStep').click(function(){
		$('.step_form').slick('slickGoTo', 1);
	});	
	$('#secondStep').click(function(){
		$('.step_form').slick('slickGoTo', 2);
	});	
	$('#thirdstep').click(function(){
		$('.step_form').slick('slickGoTo', 3);
	});
	$('#fourthstep').click(function(){
		$('.step_form').slick('slickGoTo', 4);
	});
	$('#stepfive').click(function(){
		$('.step_form').slick('slickGoTo', 5);
	});		
	$('.prevStep').click(function(e){
		e.preventDefault();
	//	alert('asdasda');
		var step = $(this).attr('data-prev');
		var activeCls = step-1;
		$('.step_form').slick('slickGoTo', activeCls);
	});	
	
	$(document).on('click','span.payement.prev-btn',function(e){
		e.preventDefault();
		var step = $(this).attr('data-prev'); 
		var activeCls = step-1;
		$('.step_form').slick('slickGoTo', activeCls);
	});
		
	$('.step_form').on('afterChange', function(event, slick, currentSlide, nextSlide){
		var activeCls = currentSlide+1;
		$('ul.navlist li').removeClass('active').each(function(index){
			if(index < activeCls){
				$(this).addClass('active');
			}
		});
		
		$('.checkout_step_nav ul.nav.nav-tabs li').each(function(){
			if($(this).attr('data-id') <= currentSlide){
				$(this).removeClass('disabled');
				$(this).addClass('active');
			}else{
				$(this).removeClass('active');
				$(this).addClass('disabled');
			}
		});
	}); 
	
	$('.checkou_login_form input#wp-submit').on('click', function(e){			
	   if(chekout_login_form_validation() == true){
			$.ajax({
				type: 'POST',
				dataType: 'json',
				url: wpObj.ajaxurl,
				data: { 
					'action': 'checkoutajaxlogin', //calls wp_ajax_nopriv_ajaxlogin
					'username': $('.checkou_login_form  #user_login').val(), 
					'password': $('.checkou_login_form  #user_pass').val(), 
					'rememberme': $('.checkou_login_form   #rememberme').val() },
				success: function(data){
					$('.checkou_login_form p.login-status').html(data.message);					
					if (data.loggedin == true){
						$('.checkou_login_form p.login-status').removeClass('error');
						document.location.href = data.redirect;
					}else{
						$('.checkou_login_form p.login-status').addClass('error');
					}
				}
			}); 
		}
        e.preventDefault();
    });
	
	
	function chekout_login_form_validation(){
		var validate = true;
		if($('.checkou_login_form input#user_login').val() == '' || $('.checkou_login_form input#user_login').val() == null || $('.checkou_login_form input#user_login').val() == 'undefined'){
			if($('.checkou_login_form input#user_login').closest('p.login-username').find('.error_user_name').length < 1){
				$('.checkou_login_form p.login-username').append('<label class="error_user_name error">Please enter username.</label>');
			}
			var validate = false;
		}else{
			$('.checkou_login_form p.login-username .error_user_name').remove();
		}
		if($('.checkou_login_form input#user_pass').val() == '' || $('.checkou_login_form input#user_pass').val() == null || $('.checkou_login_form input#user_pass').val() == 'undefined'){
			var validate = false;
			if($('.checkou_login_form input#user_pass').closest('p.login-password').find('.error_password').length< 1){
				$('.checkou_login_form p.login-password').append('<label class="error_password error">Please enter password.</label>');
			}
			
		}else{
			$('.checkou_login_form p.login-password .error_password').remove();
		}
		return validate;
	}

	$('#checkout_coupon_code').on('change',function(){
		$('.checkout_cououn form.checkout_coupon.woocommerce-form-coupon input#coupon_code').val($(this).val());
	})
	$('#checkout_coupon_code').on('keyup',function(){
		$('.checkout_cououn form.checkout_coupon.woocommerce-form-coupon input#coupon_code').val($(this).val());
	})
	$('#checkout_coupon_code').on('keydown',function(){
		$('.checkout_cououn form.checkout_coupon.woocommerce-form-coupon input#coupon_code').val($(this).val());
	})
	
	$(document).on('click','button.button.btn.checkout_apply_coupon',function(e){
		e.preventDefault();
		$('form.checkout_coupon.woocommerce-form-coupon button.button').trigger('click');
	}); 
	
	$(document).on('click','.cuppon-box h2 a.returning_customer_button',function(e){
		e.preventDefault();
		$('.checkou_login_form').slideToggle();
	});
	
	$(document).on('click','.cuppon-box h2 a.cuppon_from_show_button',function(e){
		e.preventDefault();
		e.stopPropagation();
		$('.custom_checkout_coupon_form').slideToggle();
	});	
});


