
/************************************** Get Today Date **************************************/
var now = new Date();
var day = ("0" + now.getDate()).slice(-2);
var month = ("0" + (now.getMonth() + 1)).slice(-2);
var today = now.getFullYear()+"-"+(month)+"-"+(day) ;

$('#checkin-date').val(today);

var dropday = ("0" + (now.getDate() + 1)).slice(-2);
var dropmonth = ("0" + (now.getMonth() + 1)).slice(-2);
var droptoday = now.getFullYear()+"-"+(dropmonth)+"-"+(dropday) ;

$('#checkout-date').val(droptoday);


$('#checkin-date').change(function(){
	var getcheckin=new Date($('#checkin-date').val());
	var ndropday = ("0" + (getcheckin.getDate()+ 1)).slice(-2);
	var ndropmonth = ("0" + (getcheckin.getMonth() + 1)).slice(-2);
	var ndroptoday = getcheckin.getFullYear()+"-"+(ndropmonth)+"-"+(ndropday) ;
	$('#checkout-date').val(ndroptoday);
});


/************************************* Remove Previous Dates *****************************************/
var currentDateTime = new Date();
var year = currentDateTime.getFullYear();
var month = (currentDateTime.getMonth() + 1);
var date = (currentDateTime.getDate());
var datenext= (currentDateTime.getDate() + 1);

if(date < 10) {
  date = '0' + date;
}
if(month < 10) {
  month = '0' + month;
}

var dateToday = year + "-" + month + "-" + date;
var dateTomorrow = year + "-" + month + "-" + datenext;
var checkinElem = document.querySelector("#checkin-date");
var checkoutElem = document.querySelector("#checkout-date");

checkinElem.setAttribute("min", dateToday);

checkoutElem.setAttribute("min", dateTomorrow);

checkinElem.onchange = function () {
    checkoutElem.setAttribute("min", this.value);
}

jQuery(document).ready(function(){
	var current_h=new Date().getHours();
	var current_m=String(new Date().getMinutes()).padStart(2, '0');
	var time_result=[current_h,current_m].join('');
	var pickup_date= jQuery('#checkin-date').val();
	
	var today_date= new Date();     
	var strDate = today_date.getFullYear() + "-" + ('0' + (today_date.getMonth()+1)).slice(-2) + "-" + today_date.getDate();
	
	function disable_time(hello){
		if(hello == true){
			jQuery('#form_time option').filter(function() {
				return $(this).attr('data-id') < time_result;
			}).prop('disabled', true); 
		}else{
				jQuery('#form_time option').filter(function() {
					return $(this).attr('data-id');
				}).prop('disabled', false); 
		}
		 
	}
	disable_time(true);
		 
	jQuery('#checkin-date').change(function(){
		var pickup_date= jQuery('#checkin-date').val();
		if( pickup_date != strDate){
			disable_time(false);
		}else{
			disable_time(true);
		}
	});
	 
}); 




