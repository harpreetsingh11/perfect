<?php
function  clubforrental_css_files(){
 wp_enqueue_style( 'bootstrap-club_for_rental','https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css');
 wp_enqueue_style( 'font-awesome-club_for_rental','https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css');
 wp_enqueue_style( 'slick-club_for_rental','https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css');
 wp_enqueue_style( 'video-club_for_rental','https://unpkg.com/video.js@7/dist/video-js.min.css');
 wp_enqueue_style( 'video-club_for_rental','https://unpkg.com/video.js@7/dist/video-js.min.css');
 wp_enqueue_style( 'timepicker_css','https://cdnjs.cloudflare.com/ajax/libs/jquery-timepicker/1.10.0/jquery.timepicker.css');
 
 wp_enqueue_style('club_for_rental-styles',  get_stylesheet_directory_uri() . '/inc/assets/css/style.css?nocach='.microtime(),true);
 wp_enqueue_style('club_for_rental-custom-styles',  get_stylesheet_directory_uri() . '/inc/assets/css/custom.css?nocach='.microtime(),true);
 wp_enqueue_style('club_for_rental-responsive',  get_stylesheet_directory_uri() . '/inc/assets/css/responsive.css?nocach='.microtime(),true);

}
add_action('wp_enqueue_scripts', 'clubforrental_css_files');

function clubforrental_js_files(){
	  wp_enqueue_script('club_for_rental-js',  get_template_directory_uri() . '/inc/assets/js/custom.js?nocach='.microtime(),null,null,true);
	  wp_enqueue_script('club_for_rental-date-js',  get_template_directory_uri() . '/inc/assets/js/date.js?nocach='.microtime(),null,null,true);
	  wp_enqueue_script( 'jquery-club_for_rental','https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js',true);
	  wp_enqueue_script( 'slick-club_for_rental','https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js',true);
	  wp_enqueue_script( 'bootstrap-club_for_rental','https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js',true);
	  wp_enqueue_script( 'timepicker_js','https://cdnjs.cloudflare.com/ajax/libs/jquery-timepicker/1.10.0/jquery.timepicker.min.js',true);
	  wp_enqueue_script( 'video-club_for_rental','https://vjs.zencdn.net/7.17.0/video.min.js',true);
	  wp_enqueue_script( 'video-youtube-club_for_rental','https://cdnjs.cloudflare.com/ajax/libs/videojs-youtube/2.6.0/Youtube.min.js',true);
	  
	 
	
      wp_localize_script( 'club_for_rental-js', 'wpObj', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
	
}
add_action('wp_enqueue_scripts', 'clubforrental_js_files');



function club_for_rental_menus() {
	$locations = array(
		'primary'  => __( 'theme_location', 'Club-for-rental' ),
	);
	register_nav_menus( $locations );
}
add_action( 'init', 'club_for_rental_menus' );

function add_link_atts($atts) {
  $atts['class'] = "nav-link";
  return $atts;
}
add_filter( 'nav_menu_link_attributes', 'add_link_atts');

function my_acf_op_init() {

    // Check function exists.
    if( function_exists('acf_add_options_page') ) {

        // Add parent.
        $parent = acf_add_options_page(array(
            'page_title'  => __('Theme General Settings'),
            'menu_title'  => __('Theme Settings'),
            'redirect'    => false,
        ));
    }
}
add_action('acf/init', 'my_acf_op_init');

 function Clubs_init() {
    // set up Clubs labels
    $labels = array(
        'name' => 'Clubs',
        'singular_name' => 'Club',
        'add_new' => 'Add New Club',
        'add_new_item' => 'Add New Club',
        'edit_item' => 'Edit Club',
        'new_item' => 'New Club',
        'all_items' => 'All Clubs',
        'view_item' => 'View Clubs',
        'search_items' => 'Search Clubs',
        'not_found' =>  'No Clubs Found',
        'not_found_in_trash' => 'No Clubs found in Trash', 
        'parent_item_colon' => '',
        'menu_name' => 'Clubs',
    );
    
    // register post type
    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'show_ui' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'rewrite' => array('slug' => 'club'),
        'query_var' => true,
        'menu_icon' => 'dashicons-randomize',
        'supports' => array(
            'title' )
    );
    register_post_type( 'club', $args );
    
    // register taxonomy
    register_taxonomy('Clubs_category', 'Clubs', array('hierarchical' => true, 'label' => 'Category', 'query_var' => true, 'rewrite' => array( 'slug' => 'Clubs-category' )));
}

add_action( 'init', 'Clubs_init' ); 

add_action('woocommerce_before_single_product','customize_woocommerce_before_single_product');
function customize_woocommerce_before_single_product(){
	$product_banner=get_field('product_page_banner','option'); ?>

<?php if( $product_banner) :?>
			<section class="main-banner-sc" style="background-image:url(<?php echo $product_banner; ?>);">
				<div class="container">
					<div class="main-banner-sc-content">
						<h4><?php the_title(); ?></h4>
					</div>
				</div>
			</section>
<?php endif; ?>

	<section class="Taylormade-about-sec">
        <div class="container">
            <div class="Taylormade-about-sec-comntent">
                <div class="row">            
	<?php
}


add_filter('woocommerce_currency_symbol', 'sww_remove_wc_currency_symbols', 10, 2); 
function sww_remove_wc_currency_symbols( $currency_symbol, $currency ) {
     $currency_symbol = $currency_symbol.' ';
     return $currency_symbol;
}



add_action('woocommerce_after_single_product_summary','customize_woocommerce_before_add_to_cart_form');
function customize_woocommerce_before_add_to_cart_form(){
	?>
				</div>
            </div>
        </div>
    </section>
	<?php
}

add_action('woocommerce_single_product_summary', 'customizing_single_product_summary_hooks', 2  );
function customizing_single_product_summary_hooks(){

    remove_action('woocommerce_single_product_summary','woocommerce_template_single_price',10  );
    remove_action('woocommerce_single_product_summary','woocommerce_template_single_excerpt',20  );
    //remove_action('woocommerce_single_product_summary','woocommerce_template_single_add_to_cart',30  );
	global $product;
	
	echo $product->description;
	
}

add_filter('woocommerce_show_page_title', 'bbloomer_hide_cat_page_title');
 
function bbloomer_hide_cat_page_title($title) {
   if (is_product_category()) $title = false;
   return $title;
}


add_filter( 'woocommerce_variation_option_name','display_price_in_variation_option_name');

function display_price_in_variation_option_name( $term ) {
    global $product;

    if ( empty( $term ) ) {
        return $term;
    }
    if ( empty( $product->id ) ) {
        return $term;
    }

    $variation_id = $product->get_children();

    foreach ( $variation_id as $id ) {
        $_product       = new WC_Product_Variation( $id );
        $variation_data = $_product->get_variation_attributes();

        foreach ( $variation_data as $key => $data ) {

            if ( $data == $term ) {
                $html  = $term ;
                $html .= ' ( + ' .wp_kses( woocommerce_price( $_product->get_name() ), array() ).')' ;
                return $html;
            }
        }
    }

    return $term;

}

/**
 * Exclude products from a particular category on the shop page
 */
 add_action( 'woocommerce_product_query', 'custom_pre_get_posts_query' );  
function custom_pre_get_posts_query( $q ) {

    $tax_query = (array) $q->get( 'tax_query' );

    $tax_query[] = array(
           'taxonomy' => 'product_cat',
           'field' => 'slug',
           'terms' => array( 'uncategorized' ), // Don't display products in the uncategorized category on the shop page.
           'operator' => 'NOT IN'
    );


    $q->set( 'tax_query', $tax_query );

}





add_action('woocommerce_before_shop_loop', 'customizing_woocommerce_before_shop_loop', 2  );
function customizing_woocommerce_before_shop_loop(){

    remove_action('woocommerce_before_shop_loop','woocommerce_result_count',20  );
    remove_action('woocommerce_before_shop_loop','woocommerce_catalog_ordering',30  );
	
}

function woocommerce_template_loop_product_title() {
echo wp_kses_post( '<h6 class=”woocommerce-loop-product__title”>' . get_the_title() . '</h6>' );
}

 add_action('woocommerce_before_shop_loop_item','customize_woocommerce_before_shop_loop_item');
function customize_woocommerce_before_shop_loop_item(){
	 if(is_shop()){
?>
	<div class="col-lg-3 col-md-3">
		<div class="stick-img">
                
	 <?php
} }

add_action('woocommerce_before_shop_loop_item_title' , 'customize_woocommerce_before_shop_loop_item_title');
function customize_woocommerce_before_shop_loop_item_title(){
	 if(is_shop()){
?>
		</div>
	</div>
	<div class="col-lg-6 col-md-6">
        <div class="about-stick-dd">
	<?php
} }


add_action('woocommerce_shop_loop_item_title' , 'customize_woocommerce_shop_loop_item_title');
function customize_woocommerce_shop_loop_item_title(){
	 if(is_shop()){ global $product; 
	 $terms = get_the_terms( $product->get_id(), 'product_cat' );
	 foreach ($terms as $term) {
		 ?>
		 <small><?php echo $term->name; ?></small>
	 <?php } ?>
		<p> <?php echo the_excerpt(); ?></p>
		</div>
	</div>
	<div class="col-lg-3 col-md-3">
        <div class="stick-dd-price">
		<p>Starting From: <span><?php echo $product->get_price_html(); ?></span> </p>
		<div class="stick-dd-btn">
		
		<?php
				$featured_posts = get_field('club'); echo $featured_posts;?>
			<a href="<?php echo get_permalink($product->id) ?>">View Details</a>
		</div>
	<?php
} }


add_action('woocommerce_after_shop_loop_item', 'customizing_woocommerce_after_shop_loop_item', 2  );
function customizing_woocommerce_after_shop_loop_item(){

    remove_action('woocommerce_after_shop_loop_item','woocommerce_template_loop_add_to_cart',10  );
}

add_action('woocommerce_before_shop_loop_item', 'customizing_woocommerce_before_shop_loop_item',2 );
function customizing_woocommerce_before_shop_loop_item(){

    remove_action('woocommerce_before_shop_loop_item','woocommerce_template_loop_product_link_open',10  );
}

add_action('wp_ajax_my_search_ajax','my_search_ajax');
add_action('wp_ajax_nopriv_my_search_ajax','my_search_ajax');
function my_search_ajax(){
	if(isset($_REQUEST['post_id']) && !empty($_REQUEST['post_id']) && isset($_REQUEST['pickup_date']) && !empty($_REQUEST['pickup_date']) && isset($_REQUEST['dropoff_date']) && !empty($_REQUEST['dropoff_date']) ){
		$pickup_location=$_REQUEST['pickup_loc'];
		$pickup_date=$_REQUEST['pickup_date'];
		$pickup_time=$_REQUEST['pickup_time'];
		$dropoff_date=$_REQUEST['dropoff_date'];
		$dropoff_time=$_REQUEST['dropoff_time'];
		$post_id = $_REQUEST['post_id'];
		$Dates = getDatesFromRange($pickup_date,$dropoff_date);		
		
		$price = $_REQUEST['price'];
		$data_count = count($Dates);
		$new_price = $price + ($data_count-1)*5;
		
		$avilabel_dates = get_post_meta($post_id,'available_date',true);
		$avilabel_club = true;
		if(is_array($Dates) && count($Dates) > 0 && is_array($avilabel_dates) && count($avilabel_dates) > 0){
			foreach($Dates as $search_date){
				if(!in_array($search_date,$avilabel_dates)){
					$avilabel_club = false;
					break;
				}
			}
		}else{			
			$avilabel_club = false;
		}
		
		$pick_new_date = date("d/m/Y", strtotime($pickup_date));  
		$drop_new_date = date("d/m/Y", strtotime($dropoff_date));  		
		WC()->session->set( 'pickup_loc',$pickup_location);
		WC()->session->set( 'pickup_date',$pick_new_date);
		WC()->session->set( 'pickup_time',$pickup_time);
		WC()->session->set( 'dropoff_date',$drop_new_date);
		WC()->session->set( 'dropoff_time',$dropoff_time);
		if($avilabel_club == true){
			$response=array('success'=>true,'pickup_loc'=>$pickup_location,'pickup_date'=>$pick_new_date,'pickup_time'=>$pickup_time,'dropoff_date'=>$drop_new_date,'dropoff_time'=>$dropoff_time,'price'=>$new_price);
		}else{
			$response=array('success'=>false,'pickup_loc'=>$pickup_location,'pickup_date'=>$pick_new_date,'pickup_time'=>$pickup_time,'dropoff_date'=>$drop_new_date,'dropoff_time'=>$dropoff_time);
		}
	}else{
			$response=array('success'=>false,'pickup_loc'=>$pickup_location,'pickup_date'=>$pick_new_date,'pickup_time'=>$pickup_time,'dropoff_date'=>$drop_new_date,'dropoff_time'=>$dropoff_time);
	}
	wp_send_json($response); 
	die();
}


add_action('wp_ajax_myajax', 'myajax');
add_action('wp_ajax_nopriv_myajax', 'myajax');

function myajax() {
 
	WC()->cart->empty_cart();
	$pickup_location=$_REQUEST['pickup_loc'];
	$pickup_date =$_REQUEST['pickup_date'];
	$pickup_time =$_REQUEST['pickup_time'];
	$dropoff_date =$_REQUEST['dropoff_date'];
	$dropoff_time =$_REQUEST['dropoff_time'];
	$club_id =$_REQUEST['club_id'];

	WC()->session->set( 'pickup_loc',$pickup_location);
	WC()->session->set( 'pickup_date',$pickup_date);
	WC()->session->set( 'pickup_time',$pickup_time);
	WC()->session->set( 'dropoff_date',$dropoff_date);
	WC()->session->set( 'dropoff_time',$dropoff_time);
	WC()->session->set( 'club_id',$club_id);
	

	$quantity = 1;
	$mainproduct_id = $_POST['main_id'];
	
	$pickup_date1 = str_replace('/','-',$pickup_date);
	$dropoff_date1 = str_replace('/','-',$dropoff_date);
	$first_date = date('Y-m-d', strtotime($pickup_date1));
	$second_date = date('Y-m-d', strtotime($dropoff_date1));
	$booking_dates = getDatesFromRange($first_date,$second_date);
	
	$product = wc_get_product($mainproduct_id);
	$price = $product->get_price();
	$data_count = count($booking_dates);
	$new_price = $price + ($data_count-1)*5;
	
	
	WC()->cart->add_to_cart($mainproduct_id, $quantity,'',array(),array('custom_price'=>$new_price));
	
	//WC()->cart->add_to_cart( $mainproduct_id, $quantity);
 
	$varids = $_POST['variations_id'];
	if (!empty($varids)) {
		foreach($varids as $varids_data)
		{
			$pr_vr_explode = explode('|',$varids_data);
			$product_id = $pr_vr_explode[0];
			$variation_id = $pr_vr_explode[1];
			$quantity = 1;
			WC()->cart->add_to_cart( $product_id, $quantity, $variation_id );
		}
	}
	
	$checkedproductid=$_POST['chk_prod'];
	if (!empty($checkedproductid)) {
		foreach ($checkedproductid as $checkedproductid_data) {
			$quantity = 1;
			WC()->cart->add_to_cart( $checkedproductid_data, $quantity);
		}
	}
    
	$cart_url=wc_get_checkout_url();
	$response=array('success'=>true,'url'=>$cart_url);
	wp_send_json($response);
    die();
}

add_action('woocommerce_before_checkout_form','add_banner_checkout_page');
function add_banner_checkout_page(){
		$summary_banner= get_field('order_summary_page_banner','option'); 
		if( $summary_banner) :
	?>
	<section class="main-banner-sc" style="background-image:url(<?php echo $summary_banner; ?>);">
				<div class="container">
					<div class="main-banner-sc-content">
						<h4><?php the_title(); ?></h4>
					</div>
				</div>
			</section>
<?php 
endif;
}
remove_action( 'woocommerce_checkout_order_review', 'woocommerce_order_review', 10 );
add_action('woocommerce_checkout_before_customer_details','customize_woocommerce_checkout_before_customer_details');
function customize_woocommerce_checkout_before_customer_details(){
	
	?>	
	<section class="order-summary-sec">
		<div class="container">
			<div class="checkout_step_nav">
				<div class="wizard-inner">
					<div class="connecting-line"></div>
					<ul class="nav nav-tabs" role="tablist">
						<li role="presentation" class="active" data-id="0">
							<a href="#step1" data-toggle="tab" aria-controls="step1" role="tab" aria-expanded="true"><span class="round-tab">1 </span> <i>Details</i></a>
						</li>
						<li role="presentation" class="disabled" data-id="1">
							<a href="#step2" data-toggle="tab" aria-controls="step2" role="tab" aria-expanded="false"><span class="round-tab">2</span> <i>Products</i></a>
						</li>
						<li role="presentation" class="disabled" data-id="2">
							<a href="#step3" data-toggle="tab" aria-controls="step3" role="tab"><span class="round-tab">3</span> <i>Returning</i></a>
						</li>
						<li role="presentation" class="disabled" data-id="3">
							<a href="#step4" data-toggle="tab" aria-controls="step4" role="tab"><span class="round-tab">4</span> <i>Delivery</i></a>
						</li>
						<li role="presentation" class="disabled" data-id="4">
							<a href="#step4" data-toggle="tab" aria-controls="step4" role="tab"><span class="round-tab">5</span> <i>Billing</i></a>
						</li>
						<li role="presentation" class="disabled" data-id="5">
							<a href="#step4" data-toggle="tab" aria-controls="step4" role="tab"><span class="round-tab">6</span> <i>Payment</i></a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="container step_form">			
			<div class="order-summary-sec-content slide-1">
				<div class="inner_div">
					<?php /*<h2 class="headh2 text-center">Rental For <?php echo get_cart_booking_days(); ?> Days</h2>*/ ?>
					<div class="row">
						<div class="col-lg-6">
							<div class="pick-drop-bx">
								<p>Pickup Location</p>
								<div class="pick-drop-icon">								
									<p><?php echo WC()->session->get('pickup_loc'); ?> <img src="<?php echo get_template_directory_uri(); ?>/inc/assets/images/loc-vc.png"></p>
									<input type="hidden" name="pickup_loc" value="<?php echo WC()->session->get('pickup_loc'); ?>" >
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="pick-drop-bx">
								<p>Drop Location</p>
								<div class="pick-drop-icon">								
									<p><?php echo WC()->session->get('pickup_loc'); ?> <img src="<?php echo get_template_directory_uri(); ?>/inc/assets/images/loc-vc.png"></p>
									<input type="hidden" name="dropoff_loc" value="<?php echo WC()->session->get('pickup_loc'); ?>" >
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-6">
							<div class="pick-drop-bx">
								<p>Pickup / Delivery Date and Time</p>
								<div class="pick-drop-icon">							   
									<p><?php
										$pick_date = WC()->session->get( 'pickup_date');
										$pick_time = WC()->session->get( 'pickup_time');
										if(!empty($pick_date) || !empty($pick_time)) {
											echo $pick_date.'  '.$pick_time;
										} ?> <img src="<?php echo get_template_directory_uri(); ?>/inc/assets/images/cal-vc.png"></p>
										
										<input type="hidden" name="pickup_date" value="<?php echo $pick_date; ?>" >
										<input type="hidden" name="pickup_time" value="<?php echo $pick_time; ?>" >
								</div>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="pick-drop-bx">
								<p>Drop Off / Collection Date and Time</p>
								<div class="pick-drop-icon">							   
									<p><?php
										$drop_date = WC()->session->get( 'dropoff_date');
										$drop_time = WC()->session->get( 'dropoff_time');
										if(!empty($drop_date) || !empty($drop_time)) {
											echo $drop_date.'  '.$drop_time;
										} ?> <img src="<?php echo get_template_directory_uri(); ?>/inc/assets/images/cal-vc.png"></p>
										  
										<input type="hidden" name="dropoff_date" value="<?php echo $drop_date; ?>" >
										<input type="hidden" name="dropoff_time" value="<?php echo $drop_time; ?>" >
								</div>
							</div>
						</div>
						<div class="container mt-5">
							<div class="row">
								<div class="col-6"></div>
								<div class="col-6 d-flex justify-content-end">
									<div class="next-btn">
										<button type="button" class="btn-main" id="firstStep">NEXT</button>
									</div>
								</div>
							</div>				
							<input type="hidden" name="club_id" value="<?php echo WC()->session->get( 'club_id'); ?>" >
						</div>
					</div>
				</div>
			</div>
			<?php
	}

add_action('woocommerce_checkout_before_customer_details','woocommerce_order_review');
add_action('woocommerce_checkout_before_customer_details','woocommerce_checkout_coupon_form');

add_action('woocommerce_review_order_after_submit','customize_woocommerce_review_order_before_submit');
function customize_woocommerce_review_order_before_submit(){
	?>
		
		</div>
	</section>
	<?php
}


add_action('init', 'woocommerce_clear_cart_url');
function woocommerce_clear_cart_url() {
    if( isset($_REQUEST['clear-cart']) ) {
		WC()->cart->empty_cart();
	}
}

add_action('init', 'woocommerce_change_date_url');
function woocommerce_change_date_url() {
    if( isset($_REQUEST['change-date']) ) {
		WC()->cart->empty_cart();
	}
}

remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form');

add_filter('woocommerce_billing_fields', 'custom_woocommerce_billing_fields');

function custom_woocommerce_billing_fields($fields)
{

    $fields['billing_date'] = array(
        'label' => __('Date of Birth', 'woocommerce'), // Add custom field label
        'required' => true, // if field is required or not
        'clear' => false, // add clear or not
        'type' => 'date', // add field type
       
    );
	
	$fields['billing_confirm_email'] = array(
        'label' => __('Confirm E-mail', 'woocommerce'), // Add custom field label
        'required' => true, // if field is required or not
        'clear' => false, // add clear or not
        'type' => 'email', // add field type
       
    );
	$fields['billing_address_2'] = array(
        'label' => __('Address Line 2', 'woocommerce'), // Add custom field label
        'required' => false, // if field is required or not
        'clear' => false, // add clear or not
        'type' => 'text', // add field type
       
    );
	
	$fields['billing_company'] = array(
        'label' => __('Company Name', 'woocommerce'), // Add custom field label
        'required' => false, // if field is required or not
        'clear' => false, // add clear or not
        'type' => 'text', // add field type
       
    );
	$fields['billing_agree'] = array(
		 'label' => __(' I agree to Clubsforerental.com Terms & Conditions', 'woocommerce'), // Add custom field label
        'required' => true, // if field is required or not
        'clear' => false, // add clear or not
        'type' => 'checkbox', // add field type
       
    );

	$fields[ 'billing_city' ][ 'label' ] = 'City';
	$fields[ 'billing_state' ][ 'label' ] = 'State / Country';
	$fields[ 'billing_postcode' ][ 'label' ] = 'Zip / Post Code';
	$fields[ 'billing_country' ][ 'label' ] = 'Country';
	$fields[ 'billing_email' ][ 'label' ] = 'E-mail';
	$fields[ 'billing_address_1' ][ 'label' ] = 'Address';
	$fields[ 'billing_address_1' ][ 'placeholder' ] = '';
	$fields['billing_country']['priority'] = 200;

    return $fields;
}

add_filter('woocommerce_form_field_args',  'wc_form_field_args',10,3);
function wc_form_field_args($args, $key, $value) {
  $args['input_class'] = array( 'form-control' );
  return $args;
}


add_filter( 'woocommerce_form_field', 'my_woocommerce_form_field' );
function my_woocommerce_form_field( $field ) {
    return preg_replace(
        '#<p class="form-row (.*?)"(.*?)>(.*?)</p>#',
        '<div class="col-lg-4 col-md-4 col-sm-12 mb-5 ">$3</div>',
        $field
    );
}

add_filter( 'woocommerce_checkout_fields', 'mrks_move_checkout_fields' );

function mrks_move_checkout_fields( $fields ) {
	  $fields2['billing']['billing_first_name'] = $fields['billing']['billing_first_name'];
	  $fields2['billing']['billing_last_name']  = $fields['billing']['billing_last_name'];
	  $fields2['billing']['billing_date'] = $fields['billing']['billing_date'];
	  $fields2['billing']['billing_company']    = $fields['billing']['billing_company'];
	  $fields2['billing']['billing_phone']      = $fields['billing']['billing_phone'];
	  $fields2['billing']['billing_email']      = $fields['billing']['billing_email'];
	  $fields2['billing']['billing_confirm_email']      = $fields['billing']['billing_confirm_email'];
	  $fields2['billing']['billing_address_1']  = $fields['billing']['billing_address_1'];
	  $fields2['billing']['billing_address_2']  = $fields['billing']['billing_address_2'];
	  $fields2['billing']['billing_city']       = $fields['billing']['billing_city'];
	  $fields2['billing']['billing_postcode']   = $fields['billing']['billing_postcode'];
	  $fields2['billing']['billing_state']      = $fields['billing']['billing_state'];
	  $fields2['billing']['billing_country']    = $fields['billing']['billing_country'];
	  $fields2['billing']['billing_agree']    = $fields['billing']['billing_agree'];
	
	  $checkout_fields = array_merge( $fields, $fields2);
		return $checkout_fields;
}

add_action('woocommerce_checkout_process', 'bbloomer_matching_email_addresses');
  
function bbloomer_matching_email_addresses() { 
    $email1 = $_POST['billing_email'];
    $email2 = $_POST['billing_confirm_email'];
    if ( $email2 !== $email1 ) {
        wc_add_notice( 'Your email addresses do not match', 'error' );
    }
}

add_filter( 'woocommerce_checkout_fields' , 'custom_override_checkout_fields' );

// Our hooked in function - $fields is passed via the filter!
function custom_override_checkout_fields( $fields ) {
	 
	 $fields['order']['delivery_location'] = array(
        'label' => __('Delivery Address: Hotel / Golf Course Or Depot Pick Up', 'woocommerce'), // Add custom field label
        'required' => false, // if field is required or not
        'clear' => false, // add clear or not
        'type' => 'textarea',
       
    );
	
	$fields['order']['collection_location'] = array(
        'label' => __('Collection Address: Hotel / Golf Course Or Depot Drop Off', 'woocommerce'), // Add custom field label
        'required' => false, // if field is required or not
        'clear' => false, // add clear or not
        'type' => 'textarea',
       
    );
	
	$fields['order']['order_comments'] = array(
        'label' => __('Delivery Notes / Requests', 'woocommerce'), // Add custom field label
        'required' => false, // if field is required or not
        'clear' => false, // add clear or not
        'type' => 'textarea',
       
    );
	
	$fields['order']['reservation_name'] = array(
        'label' => __('Hotel / Golf reservation name', 'woocommerce'), // Add custom field label
        'required' => false, // if field is required or not
        'clear' => false, // add clear or not
        'type' => 'textarea',
       
    );
	 
     return $fields;
}




function club_save_extra_checkout_fields( $order_id, $posted ){
	if( isset( $_POST['pickup_loc'] ) && !empty($_POST['pickup_loc'] )){
        update_post_meta( $order_id, 'pickup_loc',$_POST['pickup_loc']);
    } 
	if( isset( $_POST['dropoff_loc'] ) && !empty($_POST['dropoff_loc'] )){
        update_post_meta( $order_id, 'dropoff_loc',$_POST['dropoff_loc']);
    } 
	if( isset( $_POST['dropoff_date'] ) && !empty($_POST['dropoff_date'] )){
        update_post_meta( $order_id, 'dropoff_date',$_POST['dropoff_date']);
    } 
	if( isset( $_POST['pickup_date'] ) && !empty($_POST['pickup_date'] )){
        update_post_meta( $order_id, 'pickup_date',$_POST['pickup_date']);
    } 
	if( isset( $_POST['pickup_time'] ) && !empty($_POST['pickup_time'] )){
        update_post_meta( $order_id, 'pickup_time',$_POST['pickup_time']);
    } 
	if( isset( $_POST['dropoff_time'] ) && !empty($_POST['dropoff_time'] )){
        update_post_meta( $order_id, 'dropoff_time',$_POST['dropoff_time']);
    } 
	if( isset( $_POST['billing_date'] ) && !empty($_POST['billing_date'] )){
        update_post_meta( $order_id, 'billing_date',$_POST['billing_date']);
    }
	if( isset( $_POST['billing_address_2'] ) && !empty($_POST['billing_address_2'] )){
        update_post_meta( $order_id, 'billing_address_2',$_POST['billing_address_2']);
    }
	if( isset( $_POST['delivery_location'] ) && !empty($_POST['delivery_location'] )){
        update_post_meta( $order_id, 'delivery_location',$_POST['delivery_location']);
    }
	if( isset( $_POST['collection_location'] ) && !empty($_POST['collection_location'] )){
        update_post_meta( $order_id, 'collection_location',$_POST['collection_location']);
    }
	if( isset( $_POST['order_comments'] ) && !empty($_POST['order_comments'] )){
        update_post_meta( $order_id, 'order_comments',$_POST['order_comments']);
    }
	if( isset( $_POST['reservation_name'] ) && !empty($_POST['reservation_name'] )){
        update_post_meta( $order_id, 'reservation_name',$_POST['reservation_name']);
    }
	if( isset( $_POST['club_id'] ) && !empty($_POST['club_id'] )){
        update_post_meta( $order_id, 'booking_club_id',$_POST['club_id']);
    }
	
} 
add_action( 'woocommerce_checkout_update_order_meta', 'club_save_extra_checkout_fields', 999, 2 );


function wocoomerce_save_booking_date($order_id) {
	if(get_post_meta($order_id,'updated_club_dates',1) != 1){
		$club_id = get_post_meta($order_id,'booking_club_id',true);
		$pickup_date = str_replace('/','-',get_post_meta($order_id, 'pickup_date', true ));
		$dropoff_date = str_replace('/','-',get_post_meta($order_id, 'dropoff_date', true ));
		$first_date = date('Y-m-d', strtotime($pickup_date));
		$second_date = date('Y-m-d', strtotime($dropoff_date));
		$booking_dates = getDatesFromRange($first_date,$second_date);
		$available_date = get_post_meta($club_id,'available_date',true);
		if($available_date){
			foreach($booking_dates as $booking){
				if(in_array($booking,$available_date)){
					$pos = array_search($booking,$available_date);
					unset($available_date[$pos]);
				}
			}  
			update_post_meta($club_id,'available_date',$available_date);
			update_post_meta($order_id,'updated_club_dates',1);
		}
	}
}
add_action('woocommerce_order_status_processing', 'wocoomerce_save_booking_date');
add_action('woocommerce_order_status_on-hold', 'wocoomerce_save_booking_date');


add_action( 'woocommerce_admin_order_data_after_billing_address', 'my_custom_checkout_field_display_admin_order_meta', 10, 1 );
function my_custom_checkout_field_display_admin_order_meta($order){
	if(get_post_meta( $order->id, 'billing_date', true )){
		echo '<p><strong>'.__('Date of Birth').':</strong> <br>' . get_post_meta( $order->get_id(), 'billing_date', true ) . '</p>';
	}
	if(get_post_meta( $order->id, 'pickup_loc', true )){
		echo '<p><strong>'.__('Pickup Location').':</strong> <br>' . get_post_meta( $order->get_id(), 'pickup_loc', true ) . '</p>';
	}
	if(get_post_meta( $order->id, 'pickup_date', true )){
		echo '<p><strong>'.__('Pickup Date And Time').':</strong> <br>' . get_post_meta( $order->get_id(), 'pickup_date', true ) .'  '.get_post_meta( $order->get_id(), 'pickup_time', true ).'</p>';
	}
	if(get_post_meta( $order->id, 'dropoff_loc', true )){
		echo '<p><strong>'.__('Dropoff Location').':</strong> <br>' . get_post_meta( $order->get_id(), 'dropoff_loc', true ) . '</p>';
	}
	if(get_post_meta( $order->id, 'dropoff_date', true )){
		echo '<p><strong>'.__('Dropoff Date And Time').':</strong> <br>' . get_post_meta( $order->get_id(), 'dropoff_date', true ) .'  '.get_post_meta( $order->get_id(), 'dropoff_time', true ).'</p>';
	}
	
}


add_action( 'woocommerce_admin_order_data_after_shipping_address', 'my_custom_checkout_field_display_admin_order_meta_shiiping', 99, 1 );
function my_custom_checkout_field_display_admin_order_meta_shiiping($order){
	
	if(get_post_meta( $order->id, 'delivery_location', true )){
		echo '<p><strong>'.__('Delivery Address: Hotel / Golf Course Or Depot Pick Up').':</strong> <br>' . get_post_meta( $order->get_id(), 'delivery_location', true ) .'</p>';
	}
	if(get_post_meta( $order->id, 'collection_location', true )){
		echo '<p><strong>'.__('Collection Address: Hotel / Golf Course Or Depot Drop Off', 'woocommerce').':</strong> <br>' . get_post_meta( $order->get_id(), 'collection_location', true ) .'</p>';
	}
	if(get_post_meta( $order->id, 'reservation_name', true )){
		echo '<p><strong>'.__('Hotel / Golf reservation name', 'woocommerce').':</strong> <br>' . get_post_meta( $order->get_id(), 'reservation_name', true ) .'</p>';
	}
}

  /** 
     * Write code on Method
     *
     * @return response() 
     */ 
    function getBetweenDates($startDate, $endDate)
    {
        $rangArray = [];
            
        $startDate = strtotime($startDate);
        $endDate = strtotime($endDate);
             
        for ($currentDate = $startDate; $currentDate <= $endDate; 
                                        $currentDate += (86400)) {
                                                
            $date = date('Y-m-d', $currentDate);
            $rangArray[] = $date;
        }
  
        return $rangArray;
    }
  

/* add_action( 'wp_header', 'my_acf_save_post' ); 
function my_acf_save_post() {
	$meta_key = "not_available_date";
	echo $ppp = get_post_meta(440, $meta_key,true);
		$dates = getBetweenDates('2022-10-22', '2022-10-30');
		$date_nw = $ppp.','. implode(",",$dates);

		update_post_meta(440, $meta_key, $date_nw);

}  */

      
	  
function getDatesFromRange($start, $end, $format = 'Y-m-d') {
    $array = array();
    $interval = new DateInterval('P1D');

    $realEnd = new DateTime($end);
    $realEnd->add($interval);
    $period = new DatePeriod(new DateTime($start), $interval, $realEnd);
    foreach($period as $date) {                 
        $array[] = $date->format($format); 
    }
    return $array;
}	  
   
  



function add_location_taxonomies_in_club() {
  register_taxonomy('location', 'club', array(
    'hierarchical' => true,
    'labels' => array(
      'name' => _x( 'Locations', 'taxonomy general name' ),
      'singular_name' => _x( 'Location', 'taxonomy singular name' ),
      'search_items' =>  __( 'Search Locations' ),
      'all_items' => __( 'All Locations' ),
      'parent_item' => __( 'Parent Location' ),
      'parent_item_colon' => __( 'Parent Location:' ),
      'edit_item' => __( 'Edit Location' ),
      'update_item' => __( 'Update Location' ),
      'add_new_item' => __( 'Add New Location' ),
      'new_item_name' => __( 'New Location Name' ),
      'menu_name' => __( 'Locations' ),
    ),
    'rewrite' => array(
      'slug' => 'locations',
      'with_front' => false,
      'hierarchical' => true
    ),
  ));
}
add_action( 'init', 'add_location_taxonomies_in_club', 0 );

 
 add_action( 'pre_get_posts', 'custom_post_type_archive' );
function custom_post_type_archive( $query ) {
	if( $query->is_main_query() && !is_admin() && is_post_type_archive( 'club' ) ) {
		if(isset($_GET['location']) && !empty($_GET['location'])){
			$orgdata = $_GET['location'];
			$tax_query_values = array(
				array(
				'taxonomy' => 'location',
				'field' => 'slug',
				'terms' => $orgdata
				),  
			) ;
			$query->set('tax_query', $tax_query_values);
		}

		if(isset($_REQUEST['pickup_date']) && !empty($_REQUEST['pickup_date']) && isset($_REQUEST['dropoff_date']) && !empty($_REQUEST['dropoff_date']) ){
			$pickup_date=$_REQUEST['pickup_date'];
			$dropoff_date=$_REQUEST['dropoff_date'];
			$Dates = getDatesFromRange($pickup_date,$dropoff_date);
			
			if(is_array($Dates) && count($Dates)){
				$meta_query_values['meta_query'][] = array('relation'=>'AND');
				foreach($Dates as $search_date){
					$meta_query_values['meta_query'][] = 
						array(
							'key' => 'available_date',
							'value' => $search_date,
							'compare' => 'LIKE'
						);
				}				
				$query->set('meta_query', $meta_query_values);
			}
		}
	}
}

add_action( 'woocommerce_before_calculate_totals', 'update_custom_price', 1, 1 );
function update_custom_price( $cart_object ) {
    foreach ( $cart_object->cart_contents as $cart_item_key => $value ) {       
		//echo '<pre>'; print_r($value['custom_price']); echo '</pre>';
		if(!empty($value['custom_price'])){
			$value['data']->set_price($value['custom_price']);
		}
    }
}

function get_cart_booking_days(){
	if ( WC()->cart->get_cart_contents_count() > 0 ) {
		$pickup_date = WC()->session->GET( 'pickup_date');
		$dropoff_date = WC()->session->GET( 'dropoff_date');
		$pickup_date1 = str_replace('/','-',$pickup_date);
		$dropoff_date1 = str_replace('/','-',$dropoff_date);
		$first_date = date('Y-m-d', strtotime($pickup_date1));
		$second_date = date('Y-m-d', strtotime($dropoff_date1));
		$booking_dates = getDatesFromRange($first_date,$second_date);
		return count($booking_dates);
	}else{
		return 0;
	}
}

function get_times($default = '1900', $interval = '+30 minutes'){
	
	$output = '';

	$current = strtotime('00:00');
	$end = strtotime('23:59');

	while ($current <= $end) {
		$time = date('H:i', $current);                     
		$data_id=date('Hi', $current);
		$sel = ($data_id == $default) ? ' selected' : '';

		$output .= "<option value=\"{$time}\" data-id=\"{$data_id}\">" . date('H:i ', $current) .'</option>';
		$current = strtotime($interval, $current);
	}

	return $output;
}


add_action('wp_ajax_checkoutajaxlogin','checkoutajaxlogin');
add_action('wp_ajax_nopriv_checkoutajaxlogin','checkoutajaxlogin');
function checkoutajaxlogin(){
    $info = array();
    $info['user_login'] = $_POST['username'];
    $info['user_password'] = $_POST['password'];
    $info['remember'] = true;
    $user_signon = wp_signon( $info, false );
    if ( is_wp_error($user_signon) ){
        echo json_encode(array('loggedin'=>false, 'message'=>__('Wrong username or password.')));
    } else {
        echo json_encode(array('loggedin'=>true, 'message'=>__('Login successful, redirecting...'),'redirect'=>home_url('checkout')));
    }
    die();
}

add_action('woocommerce_review_order_before_submit','add_previous_button_befor_placeOrder');
function add_previous_button_befor_placeOrder(){
	echo '<span class="payement prev-btn" data-prev="5">Previous</span>';
} 


add_action( 'woocommerce_thankyou', 'bbloomer_add_content_thankyou' );  
function bbloomer_add_content_thankyou() {
   echo '<p>Some HTML content!</p>';
} 


add_action( 'woocommerce_email_customer_details', 'customer_note_email_after_order_table', 10, 4 );
function customer_note_email_after_order_table( $order, $sent_to_admin, $plain_text, $email ){

     if(get_post_meta( $order->get_id(), 'pickup_loc', true )) :

    $customer_note = $order->get_customer_note();

    // Display the Customer order notes section
    echo '<h2>' . __("Booking Detail", "woocommerce") . '</h2>
    <div style="margin-bottom: 40px;">
    <table cellspacing="0" cellpadding="0" style="width: 100%; color: #636363; border: 2px solid #e5e5e5;" border="0">
        <tr><th style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left;">Pickup Location:</th><td style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left;">'.get_post_meta( $order->get_id(), 'pickup_loc', true ).'</td></tr>
        <tr><th style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left;">Dropoff Location:</th><td style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left;">'.get_post_meta( $order->get_id(), 'dropoff_loc', true ).'</td></tr>
        <tr><th style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left;">Pickup Date:</th><td style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left;">'.get_post_meta( $order->get_id(), 'pickup_date', true ).'</td></tr>
        <tr><th style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left;">Dropoff Date:</th><td style="color: #636363;border: 1px solid #e5e5e5;vertical-align: middle;padding: 12px;text-align: left;">'.get_post_meta( $order->get_id(), 'dropoff_date', true ).'</td></tr>
    </table></div>';
    endif;
}


function wc_empty_cart_redirect_url() {
	return home_url();
}
add_filter( 'woocommerce_return_to_shop_redirect', 'wc_empty_cart_redirect_url' );


add_action('woocommerce_order_details_after_order_table', 'add_date_of_order',10,3);
function add_date_of_order( $order_id) {

	$pickup_date = get_post_meta($order_id->id, 'pickup_date', true );
	$pickup_loc = get_post_meta($order_id->id, 'pickup_loc', true );
	$dropoff_date = get_post_meta($order_id->id, 'dropoff_date', true );
	$dropoff_loc = get_post_meta($order_id->id, 'dropoff_loc', true );
	?>
	<div class="container">
		<div class="row">
			<div class="col-md-6 mb-3">
				<h4 class="text-success">Pickup Location</h4>
				<p><?php echo $pickup_loc; ?></p>
			</div>
			<div class="col-md-6 mb-3">
				<h4 class="text-success">Pickup Date</h4>
				<p><?php echo $pickup_date; ?></p>
			</div>
			<div class="col-md-6 mb-3">
				<h4 class="text-success">Dropoff Location</h4>
				<p><?php echo $dropoff_loc; ?></p>
			</div>
			<div class="col-md-6 mb-3">
				<h4 class="text-success">Dropoff Date</h4>
				<p><?php echo $dropoff_date; ?></p>
			</div>
		</div>
	</div>
	<?php 
}
//get_post_meta( $order->get_id(), 'delivery_location', true )

add_action('woocommerce_view_order','add_additional_information',999,4);
function add_additional_information($order_id){
	$order_comments = get_post_meta($order_id, 'order_comments', true );
	$delivery_location = get_post_meta($order_id, 'delivery_location', true );
	$collection_location = get_post_meta($order_id, 'collection_location', true );
	$reservation_name = get_post_meta($order_id, 'reservation_name', true );

	?>
	<?php if( $order_comments || $delivery_location || $reservation_name || $collection_location) :?>
	<div class="container">
		<div class="row"> 
			<h2>Additional Information</h2>
			<?php if( $delivery_location) :?>
				<div class="col-12 mb-3">
					<h4 class="text-success">Delivery Address: Hotel / Golf Course Or Depot Pick Up:</h4>
					<p><?php echo $delivery_location; ?></p>
				</div>
			<?php endif; ?>
			<?php if( $collection_location) :?>
				<div class="col-12 mb-3">
					<h4 class="text-success">Collection Address: Hotel / Golf Course Or Depot Drop Off:</h4>
					<p><?php echo $collection_location; ?></p>
				</div>
			<?php endif;?>
			<?php if( $order_comments) :?>
				<div class="col-12 mb-3">
					<h4 class="text-success">Customer provided note:</h4>
					<p><?php echo $order_comments; ?></p>
				</div>
			<?php endif; ?>
			<?php if( $reservation_name) :?>
				<div class="col-12 mb-3">
					<h4 class="text-success">Hotel / Golf reservation name:</h4>
					<p><?php echo $reservation_name; ?></p>
				</div>
			<?php endif; ?>
		</div>
	</div>
	<?php endif;
}


 function th_wc_add_my_account_orders_column( $columns ) {

        $new_columns = array();

        foreach ( $columns as $key => $name ) {

            $new_columns[ $key ] = $name;

            // add ship-to after order status column
            if ( 'order-status' === $key ) {
				
                $new_columns['order-date'] = __( 'Order Date', 'textdomain' );
                $new_columns['pickup_date'] = __( 'Pickup Date', 'textdomain' );
                $new_columns['dropoff_date'] = __( 'Dropoff Date', 'textdomain' );
            }
        }

        return $new_columns;
    }
    add_filter( 'woocommerce_my_account_my_orders_columns', 'th_wc_add_my_account_orders_column' ); 



add_action( 'woocommerce_my_account_my_orders_column_pickup_date', 'filter_woocommerce_my_account_my_orders_column_pickup_date', 10, 1 );
function filter_woocommerce_my_account_my_orders_column_pickup_date( $order ) {    
	
		$pickup_date = get_post_meta($order->id, 'pickup_date', true );
		echo $pickup_date;

} 

add_action( 'woocommerce_my_account_my_orders_column_dropoff_date', 'filter_woocommerce_my_account_my_orders_column_dropoff_date', 10, 1 );
function filter_woocommerce_my_account_my_orders_column_dropoff_date( $order ) {    
    $dropoff_date = get_post_meta($order->id, 'dropoff_date', true );
		echo $dropoff_date;
}



