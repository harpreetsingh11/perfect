
<?php $get_product_id=get_field('select_parent_product');
				$product = wc_get_product( $get_product_id );  
					$image = wp_get_attachment_image_src( get_post_thumbnail_id( $get_product_id ), 'single-post-thumbnail' ); ?>

		<div class="col-lg-6 col-md-6 col-sm-12">
            <div class="Taylormade-about-left">
                <img src="<?php echo $image[0]; ?>" class="img-fluid">
            </div>
        </div>
		<?php
		/* if ( is_singular() ) :
			the_title( '<div class="col-lg-6 col-md-6 col-sm-12"><div class="Taylormade-about-right"><p>', '</p></div></div>' );
		else :
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		endif; */

		if ( 'post' === get_post_type() ) :
			?>
			<div class="entry-meta">
				<?php
				clubforrental_posted_on();
				clubforrental_posted_by();
				?>
			</div><!-- .entry-meta -->
		<?php endif; ?>
<!-- .entry-header -->



	<div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="Taylormade-about-right">
                        <h2 class="headh2"><?php echo $product->get_name(); ?></h2>
						  <?php $terms = get_the_terms( $product->get_id(), 'product_cat' );
										foreach ($terms as $term) { ?>
											<small><?php echo $term->name; ?></small>
						<?php } ?>
                        <br>
						<?php  echo $product->get_description(); ?>
                        <div class="price-start">
                            <p>Starting From: <span><?php  echo $product->get_price_html(); ?></span> </p>
                        </div>
                    </div>
    </div>


<!-- #post-<?php the_ID(); ?> -->