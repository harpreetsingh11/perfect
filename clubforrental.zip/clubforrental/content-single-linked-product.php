<?php global $product; ?>

<!----------------------------------------- Location Layout ------------------------------------------->
<?php if( get_field('select_linked_product_layout') == 'location_layout'): ?>
			<div class="row">
                <div class="col-md-12">
                    <div class="dl-location">
                        <div class="dl-text">
                            <p><?php echo $product->description; ?></p>
                            <a href="#" class="green">View Map</a>
                        </div>
                        <div class="dl-bar">
                            <div class="form_row">
                                <div class="form-group">
									<?php $variations = $product->get_attributes(); ?>
										<?php foreach ( $variations as $product_attribute) : 
										$values = array_map( 'trim', explode( WC_DELIMITER, $product_attribute['value'] ) );?>
											
												<label><?php echo wp_kses_post( $product_attribute['name'] ); ?></label>
												<select class="custom form-cont">
													<?php foreach ( $values as $value ):
														$selected_value = '';
																printf(
																	'<option value="%s" %s>%s</option>',
																	esc_attr( $value ),
																	selected( $selected_value, $value, false ),
																	apply_filters( 'woocommerce_variation_option_name', $value ,$term)
																);
															endforeach; ?>
												</select>
											
										<?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php endif; ?>

<!----------------------------------------- Default Layout ------------------------------------------->
<?php if( get_field('select_linked_product_layout') == 'default_layout'): $imagesrc = wp_get_attachment_image_src( get_post_thumbnail_id( $product->id ));?>	
<section class="platinum-sec">
        <div class="container">
            <div class="row up-border">
                <div class="col-md-5">
				<?php if( $imagesrc) :?>
                    <div class="platinum-img">
                        <img src="<?php echo $imagesrc[0]; ?>" alt="" class="img-fluid">
                    </div>
				<?php endif; ?>
                </div>
                <div class="col-md-7">
                    <div class="platinum-text">
                        <h4><?php echo $product->name; ?></h4>
						<?php if( !empty($product->description)) :?>
                        <div class="platinum-list">
                            <?php echo $product->description; ?>
                        </div>
						<?php endif; ?>
                    </div>
					<?php if( empty($product->short_description)) :?>
					 <div class="dl-bar dl-bars">
                        <div class="form_row">
                            <div class="form-group">
                                <?php $variations = $product->get_attributes(); ?>
										<?php foreach ( $variations as $product_attribute) : 
										$values = array_map( 'trim', explode( WC_DELIMITER, $product_attribute['value'] ) );?>
											<label><?php echo wp_kses_post( $product_attribute['name'] ); ?></label>
                                    <select class="custom form-cont">
                                        <?php foreach ( $values as $value ):
														$selected_value = '';
																printf(
																	'<option value="%s" %s>%s</option>',
																	esc_attr( $value ),
																	selected( $selected_value, $value, false ),
																	apply_filters( 'woocommerce_variation_option_name', $value ,$term)
																);
															endforeach; ?> 
                                    </select>
								<?php endforeach; ?>
                            </div>
                        </div>
                    </div>
					<?php endif; ?>
                </div>
            </div>
			<?php if( !empty($product->short_description)) :?>
            <div class="choose-sec">
                <div class="row">
				
				<?php if( !empty($product->short_description)) :?>
                    <div class="col-md-7">
                        <div class="choose">
                            <div class="choose-list">
                                <?php echo $product->short_description; ?>
                                <a href="#" class="green">Here</a>
                            </div>
                        </div>
                    </div>
				<?php endif; ?>
				
				<?php if( !empty($product->short_description)) :?>
                    <div class="col-md-5">
                        <div class="platinum-menu">
                            <div class="form_row">
                                <div class="form-group">
								<?php $variations = $product->get_attributes(); ?>
										<?php foreach ( $variations as $product_attribute) : 
										$values = array_map( 'trim', explode( WC_DELIMITER, $product_attribute['value'] ) );?>
											<label><?php echo wp_kses_post( $product_attribute['name'] ); ?></label>
                                    <select class="custom form-cont">
                                        <?php foreach ( $values as $value ):
														$selected_value = '';
																printf(
																	'<option value="%s" %s>%s</option>',
																	esc_attr( $value ),
																	selected( $selected_value, $value, false ),
																	apply_filters( 'woocommerce_variation_option_name', $value ,$term)
																);
															endforeach; ?> 
                                    </select>
								<?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
				<?php endif; ?>
                </div>
            </div>
		<?php endif; ?>
        </div>
    </section>
<?php endif; ?>

<!----------------------------------------- Extra Club Layout ------------------------------------------->
<?php if( get_field('select_linked_product_layout') == 'extra_club_layout'): $imagesrc = wp_get_attachment_image_src( get_post_thumbnail_id( $product->id ));?>


                <div class="col-md-6">
                    <div class="extra-club-content">
                        <div class="wedge">
                            <p><?php echo $product->name; ?>
                                <b><?php echo $product->get_price_html(); ?></b>
                            </p>
                            <label class="cont">
                                <input type="checkbox" checked="checked">
                                <span class="checkmark"></span>
                            </label>
                        </div>
                        <div class="wedge-img">
                            <img src="<?php echo $imagesrc[0]; ?>" alt="" class="img-fluid">
                        </div>
                    </div>
                </div>
                
           
<?php endif; ?>