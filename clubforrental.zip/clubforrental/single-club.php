<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package clubforrental
 */

get_header();
$clubforrental_banner= get_field('club_page_banner','option'); 
$current_post_id = get_the_id();
$parent_product_id=get_field('select_parent_product',$current_post_id);
$sub_product_ids = get_field('select_sub_products',$current_post_id);
$products = wc_get_product( $parent_product_id );
?>
<div class="loading">Loading</div>
<?php if( $clubforrental_banner) :?>
			<section class="main-banner-sc" style="background-image:url(<?php echo $clubforrental_banner; ?>);">
				<div class="container">
					<div class="main-banner-sc-content">
						<h4><?php the_title(); ?></h4>
					</div>
				</div>
			</section>
<?php endif; ?>

		<section class="Taylormade-about-sec">
			<div class="container">
				<div class="Taylormade-about-sec-comntent">
					<div class="row">

					<?php
						
						 $product = wc_get_product( $parent_product_id );
						 
						get_template_part( 'template-parts/content-clubs', get_post_type() );

					?>
					</div>
				</div>
			</div>
		</section>

<!------------------------------------- Search Section  --------------------------------------------->
<section class="search-club-sec my-5">
    <div class="container">
        <div class="search-club-form">
            <form id="search_form" name="search_form">               
                <div class="form-row">
                    <div class="col-lg-2 col-md-6 col-sm-6">
                       <div class="form-group">
                            <label for="exampleFormControlSelect1">Pickup Location</label>
                            <select class="form-control" id="exampleFormControlSelect1" name="pickup_loc">
                              <option>Ireland</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="form-group">
                             <label>Pickup / Delivery Date and Time</label>
                             <span class="vriplacesp">
                            <!-- <input class="example" type="text" name="jQueryScript" value=""> -->
                            <input type="date" id="checkin-date" class="form-control" name="pickup_date">
                             <select name="picktime" id="form_time" class="form-control" aria-label="Default select example"><?php echo get_times(); ?></select>  
                            <input class="" type="text" name="jQueryScript" value="2022-05-25 03:04" done="true" style="display: none;">
                            </span>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="form-group">
                             <label>Drop Off / Collection Date and Time</label>
                             <span class="vriplacesp">
                            <!-- <input class="form-control" type="text" name="jQueryScript" value=""> -->
                            <input type="date" id="checkout-date" class="form-control example" name="dropoff_date">
                            <select name="droptime" class="form-control" aria-label="Default select example"><?php echo get_times(); ?></select>
                            <input class="" type="text" name="jQueryScript" value="2022-05-25 03:04" done="true" style="display: none;">
                            </span>
                        </div>
                    </div>
                    
                    <div class=" col-lg-2 col-md-3 col-sm-3">
                        <div class="form-group">
                        <button  class="btn" id="submit-btn-search">Submit</button>
                        </div>
                    </div>
					
					<input type="hidden" name="action" value="my_search_ajax">
					<input type="hidden" name="post_id" value="<?php echo get_the_ID(); ?>"> 
					<input type="hidden" name="price" value="<?php echo $products->get_price(); ?>"> 
                </div>
            </form>
        </div>
		<div class="search_club_form_error" style="display:none;" data-title="<?php echo get_the_title(get_the_ID()); ?>"> </div>
    </div>
</section>
<?php 
if(!empty($sub_product_ids))
{
	?>
	<section class="option-sec" id="option-available">
		<form id="add_to_cart_form" action="" method="post"  enctype="multipart/form-data">
			<input type="hidden" name="main_id" value="<?php echo $parent_product_id; ?>">
			<input type="hidden" name="club_id" value="<?php echo get_the_ID(); ?>">
			<input type="hidden" name="pickup_loc" value="<?php echo WC()->session->get('pickup_loc'); ?>">
			<input type="hidden" name="pickup_date" value="<?php echo WC()->session->get('pickup_date'); ?>">
			<input type="hidden" name="pickup_time" value="<?php echo WC()->session->get('pickup_time'); ?>">
			<input type="hidden" name="dropoff_date" value="<?php echo WC()->session->get('dropoff_date'); ?>">
			<input type="hidden" name="dropoff_time" value="<?php echo WC()->session->get('dropoff_time'); ?>">
			<div class="container">

				<!--HEAD SECTION -->

				<div class="option-head">
                <h4>Options Available</h4>
                <div class="option-btn">
                    <a href="" class="club_total_price">Club Rental Price:<span class="green"><?php echo $products->get_price_html(); ?></span></a>
                </div>
         		</div>

         		<!--HEAD SECTION -->

         		<!--SUB PRODUCTS SECTION -->
				
         		<?php
         		foreach($sub_product_ids as $sub_product_id_data)
         		{
         			$select_linked_product_layout = get_field('select_linked_product_layout',$sub_product_id_data);
         			$get_layouts[] = get_field('select_linked_product_layout',$sub_product_id_data);
         				$sub_products = wc_get_product( $sub_product_id_data );
         				if( $select_linked_product_layout == 'location_layout')
         				{
         					?>
         								<div class="row ">
												<div class="col-md-12">
													<div class="dl-location">
														<div class="dl-text">
															<p><?php echo $sub_products->description; ?></p>
															<a href="#" class="green">View Map</a>
														</div>

														<div class="dl-bar">
															<div class="form_row">
																<div class="form-group">
																	<?php $variations = $sub_products->get_available_variations(); 
																	 
																				foreach ($sub_products->get_attributes() as $taxonomy => $attribute_obj ) {
																							// Get the attribute label
																								$attribute_label_name = wc_attribute_label($taxonomy);

																								// Display attribute labe name
																								echo '<label><span>'.$attribute_label_name.'</span></label>';
																				}?>
																				<select class="custom form-cont" name="variations_id[]">
																				<?php foreach ( $variations as $product_attribute) : 
																				$attributes=$product_attribute['attributes']; 
																				$attribute_name='';
																				foreach( $attributes as $attribute) {
																					$attribute_name .= $attribute;
																				}
																				
																				?>
																			<option data-prod="<?php echo $sub_product_id_data; ?>" value="<?php echo $sub_product_id_data.'|'.$product_attribute['variation_id']; ?>"><?php echo $attribute_name . '  (+ '.$product_attribute['price_html'].' )';  ?></option>
																					<?php endforeach; ?>
																				</select>
																			
																		
																</div>
															</div>
														</div>

													</div>
												</div>
											</div>
         					<?php
         				}
							

         				if( $select_linked_product_layout == 'default_layout')
         				{
         					$imagesrc = wp_get_attachment_image_src( get_post_thumbnail_id( $sub_products->id ));
         					?>
         					<section class="platinum-sec">
											<div class="container">
												<div class="row up-border">
													<div class="col-md-5">
													<?php if( $imagesrc) :?>
														<div class="platinum-img">
															<img src="<?php echo $imagesrc[0]; ?>" alt="" class="img-fluid">
														</div>
													<?php endif; ?>
													</div>
													<div class="col-md-7">
														<div class="platinum-text">
															<h4><?php echo $sub_products->name; ?></h4>
															<?php if( !empty($sub_products->description)) :?>
															<div class="platinum-list">
																<?php echo $sub_products->description; ?>
															</div>
															<?php endif; ?>
														</div>
														<?php if( empty($sub_products->short_description)) :?>
														 <div class="dl-bar dl-bars">
															<div class="form_row">
																<div class="form-group">
																	<?php $variations = $sub_products->get_available_variations(); 
																	 
																				foreach ($sub_products->get_attributes() as $taxonomy => $attribute_obj ) {
																							// Get the attribute label
																								$attribute_label_name = wc_attribute_label($taxonomy);

																								// Display attribute labe name
																								echo '<label><span>'.$attribute_label_name.'</span></label>';
																				}?>
																				<select class="custom form-cont" name="variations_id[]">
																				<?php foreach ( $variations as $product_attribute) : 
																				$attributes=$product_attribute['attributes']; 
																				$attribute_name='';
																				foreach( $attributes as $attribute) {
																					$attribute_name .= $attribute;
																				}
																				
																				?>
																					<option data-prod="<?php echo $sub_product_id_data; ?>" value="<?php echo $sub_product_id_data.'|'.$product_attribute['variation_id']; ?>"><?php echo $attribute_name . '  (+ '.$product_attribute['price_html'].' )';  ?></option>
																					<?php endforeach; ?>
																				</select>
																			
																		
																</div>
															</div>
														</div>
														<?php endif; ?>
													</div>
												</div>
												<?php if( !empty($sub_products->short_description)) :?>
												<div class="choose-sec">
													<div class="row">
													
													<?php if( !empty($sub_products->short_description)) :?>
														<div class="col-md-7">
															<div class="choose">
																<div class="choose-list">
																	<?php echo $sub_products->short_description; ?>
																	<!-- <a href="#" class="green">Here</a> -->
																</div>
															</div>
														</div>
													<?php endif; ?>
													
													<?php if( !empty($sub_products->short_description)) :?>
														<div class="col-md-5">
															<div class="platinum-menu">
																<div class="form_row">
																	<div class="form-group" >
																	<?php $variations = $sub_products->get_available_variations(); 
																				foreach ($sub_products->get_attributes() as $label ) {
																							// Get the attribute label
																								$label_name = get_taxonomy( $taxonomy )->labels->singular_name;
																								// Display attribute labe name
																								echo '<label style="text-transform: capitalize;"><span>'.$label_name.'</span></label>';
																				}?>
																				<select class="custom form-cont" name="variations_id[]">
																				<?php foreach ( $variations as $product_attribute) : 
																				$attributes=$product_attribute['attributes']; 
																				$attribute_name='';
																				foreach( $attributes as $attribute) {
																					$attribute_name .= $attribute;
																				}
																				
																				?>
																					<option data-prod="<?php echo $sub_product_id_data; ?>" value="<?php echo $sub_product_id_data.'|'.$product_attribute['variation_id']; ?>"><?php echo $attribute_name . '  (+ '.$product_attribute['price_html'].' )';  ?></option>
																					<?php endforeach; ?>
																				</select>
																			
																		
																</div>
																</div>
															</div>
														</div>
													<?php endif; ?>
													</div>
												</div>
											<?php endif; ?>
											</div>
										</section>
         					<?php
         				}

         				
         		}
         		
         		if (in_array("extra_club_layout", $get_layouts))
         			{
         				?>
         				<section class="extra-club-sec">
         		 	
					        <div class="container">
					        	
					            	<h3>Extra Club Options Available</h3>
					            
					            <div class="row">
					                <?php 
					                	foreach($sub_product_ids as $sub_product_id_data)
					         			{
					         			$select_linked_product_layout = get_field('select_linked_product_layout',$sub_product_id_data);
					         				$sub_products = wc_get_product( $sub_product_id_data );
					                	if( $select_linked_product_layout == 'extra_club_layout')
				         				{
				         					$imagesrc = wp_get_attachment_image_src( get_post_thumbnail_id( $sub_products->id ));
				         					?>
				         					<div class="col-md-6">
						                    <div class="extra-club-content">
						                        <div class="wedge">
						                            <p><?php echo $sub_products->name; ?>
						                                <b><?php echo $sub_products->get_price_html(); ?></b>
						                            </p>
						                            <label class="cont">
						                                <input type="checkbox" value="<?php echo $sub_product_id_data; ?>" name="chk_prod[]">
						                                <span class="checkmark"></span>
						                            </label>
						                        </div>
						                        <?php if( $imagesrc): ?>
						                        <div class="wedge-img">
						                            <img src="<?php echo $imagesrc[0]; ?>" alt="" class="img-fluid">
						                        </div>
						                        <?php endif; ?>
						                    </div>
						                </div>
				         					<?php
				         				}
				         			}
					                ?>
					                
					            </div>
					            
					        </div>

			    		</section>	
         				<?php
         			}
         		?>
         		 
			    	<div class="wedge-btns my-5">
	                <div class="bk-btn">
	                    <a href="">back</a>
	                </div>
	                <div class="extra-btn">
	                    <button id="ajax_add_cart">book now</button>
	                </div>
            		</div>
			</div>
			<input type="hidden" name="action" value="myajax">
			<?php 
				/*foreach($sub_product_ids as $sub_product_id_data)
         		{
         			?>
         			<input type="hidden" name="Productandvar[]" id="pro-<?php echo $sub_product_id_data; ?>" value="">
         			<?php
         		}*/
			?>
		</form>
	</section>
	<?php
}

get_footer();
?>
