<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package clubforrental
 */

get_header();
?>

<main id="primary" class="harpreet site-main">
<?php  $imagebanner= get_field('shop_page_banner', 'option');  ?>
<section class="main-banner-sc"style="background-image:url(<?php echo $imagebanner; ?>);">
    <div class="container">
        <div class="main-banner-sc-content">
            <h4>View All Clubs</h4>
        </div>
    </div>
</section>

		<section class="sticks-detail-sec">
			<div class="container">
				<div class="s-d-box">

						<?php if ( have_posts() ) : 
						
							/* Start the Loop */
							while ( have_posts() ) :
								the_post();
								$get_product_id=get_field('select_parent_product');
								$product = wc_get_product( $get_product_id );  
								$image = wp_get_attachment_image_src( get_post_thumbnail_id( $get_product_id ), 'single-post-thumbnail' );
									?>
										<div class="row sticks-dt">
											<div class="col-lg-3 col-md-3">
												<div class="stick-img">
													<img src="<?php echo $image[0]; ?>">
												</div>  
											</div>
											<div class="col-lg-6 col-md-6">
												<div class="about-stick-dd">
													<h6><?php echo $product->get_name(); ?></h6>
													<p><?php $terms = get_the_terms( $product->get_id(), 'product_cat' );
																	foreach ($terms as $term) { ?>
																		<small><?php echo $term->name; ?></small>
													<?php } ?>
													</p>
													<?php  echo $product->get_short_description(); ?>
												</div>
											</div>
											<div class="col-lg-3 col-md-3">
												<div class="stick-dd-price">
													<p>Starting From: <span><?php  echo $product->get_price_html(); ?></span> </p>
													<div class="stick-dd-btn">
														<a href="<?php the_permalink(); ?>">Check Availability</a>
													</div>
												</div>
											</div>
										</div>
									<?php
							endwhile;

							the_posts_navigation();

						else :

							get_template_part( 'template-parts/content', 'noneclub' );

						endif;
						?>
				</div>
			</div>
		</section>
	</main><!-- #main -->

<?php
//get_sidebar();
get_footer();